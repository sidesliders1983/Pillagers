import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';
import { join, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

const root = resolve(process.env.QA_ROOT || process.cwd());
const pin = String(process.env.QA_GO || '');
const git = 'C:/Users/Devoteam/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe';
assert.match(pin, /^[a-f0-9]{40}$/, 'QA_GO must name the exact frozen source commit');
assert.equal(execFileSync(git, ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(), pin);
assert.equal(execFileSync(git, ['status', '--porcelain', '--untracked-files=no'], { cwd: root, encoding: 'utf8' }).trim(), '');
const { loadTypeScript } = await import(pathToFileURL(join(root, 'scripts/load-typescript.mjs')));
const load = name => loadTypeScript(pathToFileURL(join(root, 'src', name + '.ts')));
const core = load('simulation/SimulationCore');
const { SharedSettlement } = load('play/SharedSettlement');
const { GameplaySession } = load('gameplay-lab/GameplaySession');
const { adoptCampaignIsland, islandRecipe } = load('fjord-play/CampaignIsland');
const { campaignIslandCatalog } = load('fjord-play/BakedIslandCatalog');
const { fjordLivestockRules } = load('config/FjordLivestock');
const digest = text => createHash('sha256').update(text).digest('hex');
const output = resolve(root, 'scratch/equipment-309/fixtures-' + pin.slice(0, 8));
mkdirSync(output, { recursive: true });
const executedScript = readFileSync(fileURLToPath(import.meta.url));
writeFileSync(join(output, 'executed-fixture-script.mjs'), executedScript);
const sourceNames = ['simulation/SimulationCore', 'simulation/OnSiteEncounters', 'simulation/Smithery', 'simulation/SpatialExpeditions', 'fjord-play/FjordProjection', 'fjord-play/FjordWardrobe', 'fjord-play/RivalSettlement', 'characters/CharacterPresentation', 'characters/MeshyHuman', 'characters/ResidentPortraitStudio', 'characters/EquipmentPortraitFraming'];
const sourceHashes = () => Object.fromEntries(sourceNames.map(name => [name, digest(readFileSync(join(root, 'src', name + '.ts')))]));
const sourceStart = sourceHashes();
const seed = Number(process.env.QA_SEED || 72);
const recipe = islandRecipe(seed, 'island-pool-v3');
const baked = campaignIslandCatalog.entries.find(entry => entry.version === recipe.version && entry.seed === recipe.seed);
const compressed = readFileSync(join(root, 'public' + baked.path));
assert.equal(digest(compressed), baked.sha256);
const canonical = gunzipSync(compressed);
assert.equal(digest(canonical), baked.canonicalSha256);
const { world, plan } = JSON.parse(canonical);
adoptCampaignIsland(seed, world, plan);
const quiet = { mortalityBands: [{ minAge: 0, chanceBps: 0 }], fertilityChanceBps: 0, partnershipChanceBps: 0 };
const session = new GameplaySession(seed, seed, false);
session.loadJSON(core.serializeState(core.createCampaign(seed,
    { initialFood: 100000, initialMaterials: 1000, cattleBirthChanceBps: 0 }, quiet,
    { enabled: false }, {}, { enabled: false }, {}, 'summer-800-v1', undefined,
    { player: fjordLivestockRules })));
const shared = new SharedSettlement(session, undefined, false, recipe.version);
shared.fjord.enableDiscovery();
shared.command({ type: 'UseSeasonalWeatherProduction' });
shared.command({ type: 'UseCulturalOccasions' });
const state = () => shared.session.readSnapshot();
const command = value => shared.command(value);
const advance = (ticks = 1) => command({ type: 'AdvanceTicks', ticks });
const latest = () => Object.values(state().world.spatial?.missions || {}).at(-1);
const report = { status: 'preparing', source: { head: pin, hashes: sourceStart }, executedScriptSha256: digest(executedScript), seed, recipe,
    bakedSha256: baked.sha256, startedAt: new Date().toISOString(), fixtures: [],
    limits: 'Funded initial stocks and quiet natural mortality/fertility/partnership isolate rendering. Actual generated people, unchanged prepared geography, real crafting/slaughter/allocations and paid public scouting/missions only. No actor, visibility or combat outcome injection. Native/emulated browser proof is separate.' };
function wait(predicate, bound = 1500, step = 5) {
    for (let advanced = 0; advanced < bound && !predicate(); advanced += step) advance(step);
    assert.ok(predicate(), 'A real public journey did not reach the checkpoint in ' + bound + ' ticks');
}
function camera(owner, id, direction = [1, .55, 1], range = 6) {
    const entity = owner.fjord.readProjection().entities.find(entity => entity.id === id && entity.kind === 'persona');
    assert.ok(entity?.transform, 'The requested actual actor must have a public world position');
    const point = entity.transform;
    owner.setPresentation({ quality: 'low', effects: 'off', hdr: false,
        camera: { target: [point.x, point.y + .85, point.z],
            position: [point.x + direction[0] * range, point.y + .85 + direction[1] * range,
                point.z + direction[2] * range] } });
}
function store(name, owner = shared, selection = null) {
    owner.session.setRunning(false);
    owner.select(selection);
    const text = owner.persist();
    const restored = SharedSettlement.restore(text, 'fjord');
    assert.equal(restored.session.saveJSON(), owner.session.saveJSON());
    assert.equal(restored.persist(), text);
    const path = join(output, name + '.shared.json');
    writeFileSync(path, text);
    const item = { name, path, bytes: Buffer.byteLength(text), sha256: digest(text), time: { ...owner.session.readSnapshot().time } };
    report.fixtures.push(item);
    return text;
}
try {
    command({ type: 'AssignOccupation', personaId: 'founder-9', occupation: 'smith' });
    command({ type: 'AssignOccupation', personaId: 'founder-10', occupation: 'leatherAndJewelleryMaker' });
    const eligibleAnimal = Object.values(state().landing.cattle).find(animal => animal.deathWinter === null &&
        (state().landing.livestock.profiles[animal.species]?.hides ?? fjordLivestockRules.hides[animal.species] ?? 0) > 0);
    assert.ok(eligibleAnimal, 'An actual hide-bearing animal is needed for the leather shield');
    command({ type: 'SlaughterLivestock', livestockId: eligibleAnimal.id });
    for (const [item, target] of [['woodenSpear', 3], ['woodenShield', 2], ['leatherShield', 2]])
        command({ type: 'SetSmitheryTarget', item, target });
    wait(() => state().smithery.stored.woodenSpear >= 3 && state().smithery.stored.woodenShield >= 2 &&
        state().smithery.stored.leatherShield >= 1, 6000, 25);
    report.craftedAt = { ...state().time };
    report.craftingState = structuredClone(state().smithery);
    const members = core.inspectWorld(state()).eligible.slice(0, 4).map(person => person.id);
    assert.equal(members.length, 4);
    report.memberIds = members;
    report.loadouts = [
        { id: members[0], weapon: 'woodenSpear', shield: 'woodenShield' },
        { id: members[1], weapon: 'woodenSpear', shield: null },
        { id: members[2], weapon: null, shield: 'leatherShield' },
        { id: members[3], weapon: null, shield: null },
    ];
    for (const person of report.loadouts) for (const slot of ['weapon', 'shield'])
        if (person[slot]) command({ type: 'AssignEquipment', personaId: person.id, slot, item: person[slot] });
    command({ type: 'CreateExpeditionGroup', name: 'Equipment review party', memberIds: members });
    command({ type: 'StartExpedition', groupId: 'group-1' });
    command({ type: 'ExploreArea', groupId: 'group-1', target: world.rivalSite.center });
    wait(() => Object.keys(state().world.islandIntel?.sites || {}).length > 0, 900);
    const siteId = Object.keys(state().world.islandIntel.sites)[0];
    const sighting = core.inspectSpatialExpeditions(state()).missions.at(-1).position;
    report.siteId = siteId;
    const reconTarget = { kind: 'area', position: { x: sighting.x, z: sighting.z } };
    command({ type: 'RecallExpedition', groupId: 'group-1' });
    wait(() => latest().status === 'Returned');
    let knowledge;
    for (let attempt = 0; attempt < 3 && !knowledge?.settlementName; attempt++) {
        command({ type: 'DispatchIslandMission', groupId: 'group-1', target: reconTarget, mission: 'Recon' });
        wait(() => latest().status === 'Returned');
        knowledge = core.inspectIslandMissions(state()).sites.find(site => site.id === siteId)?.knowledge;
    }
    assert.ok(knowledge?.settlementName && knowledge?.opportunity);
    shared.fjord.enableTerritorialAwareness();
    camera(shared, members[0]);
    const home = store('crafted-ready-at-home');
    const none = SharedSettlement.restore(home, 'fjord');
    for (const person of report.loadouts) for (const slot of ['weapon', 'shield'])
        if (person[slot]) none.command({ type: 'AssignEquipment', personaId: person.id, slot, item: null });
    store('matched-no-equipment-at-home', none);
    command({ type: 'DispatchIslandMission', groupId: 'group-1', target: { kind: 'site', siteId },
        mission: 'Pillage', priorities: ['Food'] });
    advance(1);
    camera(shared, members[0]);
    const departed = store('actual-geared-departure');
    none.command({ type: 'DispatchIslandMission', groupId: 'group-1', target: { kind: 'site', siteId },
        mission: 'Pillage', priorities: ['Food'] });
    none.command({ type: 'AdvanceTicks', ticks: 1 });
    none.setPresentation(shared.presentation);
    store('matched-no-equipment-departure', none);
    for (const [name, direction] of [['view-a', [1, .55, 1]], ['view-b', [-1, .55, 1]], ['view-c', [-1, .55, -1]]]) {
        const view = SharedSettlement.restore(departed, 'fjord');
        camera(view, members[0], direction);
        store('geared-' + name, view);
    }
    let contact = false, exchange = false, death = false, withdrawal = false;
    for (let advanced = 0; advanced < 1500 && !['Returned', 'Lost', 'Stranded'].includes(latest().status); advanced++) {
        advance();
        const mission = latest(), encounter = state().world.encounters?.records[mission.task.encounterRules.encounterId];
        if (!contact && encounter?.phase === 'engaging') {
            store('actual-geared-contact'); contact = true;
        }
        if (!exchange && encounter?.exchanges.length) {
            store('actual-geared-first-exchange'); exchange = true;
        }
        if (!death && state().events.some(event => event.type === 'PersonaDied' && event.details?.cause === 'Combat' && event.details?.missionId === mission.id)) {
            store('actual-geared-casualty'); death = true;
        }
        if (!withdrawal && encounter?.phase === 'withdrawing') {
            store('actual-geared-withdrawal'); withdrawal = true;
        }
    }
    report.result = structuredClone(latest());
    report.encounters = structuredClone(state().world.encounters);
    const recordedEncounter = Object.values(state().world.encounters?.records || {}).at(-1);
    if (recordedEncounter) {
        for (const [name, leadTicks] of [['actual-geared-before-contact', 5], ['actual-geared-approach', 40]]) {
            const replay = SharedSettlement.restore(departed, 'fjord');
            const replayState = replay.session.readSnapshot();
            const replayTick = replayState.time.winter * replayState.ticksPerWinter + replayState.time.tick;
            const count = recordedEncounter.startedAt - leadTicks - replayTick;
            if (count >= 0) {
                replay.command({ type: 'AdvanceTicks', ticks: count });
                camera(replay, members[0]);
                store(name, replay);
            }
        }
    }
    store('actual-geared-after-journey');
    report.sourceEnd = sourceHashes();
    assert.deepEqual(report.sourceEnd, sourceStart, 'Pinned source changed during fixture generation');
    assert.equal(execFileSync(git, ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(), pin);
    assert.equal(execFileSync(git, ['status', '--porcelain', '--untracked-files=no'], { cwd: root, encoding: 'utf8' }).trim(), '');
    report.status = 'passed';
} catch (error) {
    report.status = 'failed'; report.error = error.stack; report.lastMission = latest(); report.lastTime = state().time; report.lastWorld = state().world; process.exitCode = 1;
} finally {
    report.finishedAt = new Date().toISOString();
    writeFileSync(join(output, 'report.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify({ status: report.status, output, fixtures: report.fixtures.length, error: report.error?.split('\n')[0] }));
}






