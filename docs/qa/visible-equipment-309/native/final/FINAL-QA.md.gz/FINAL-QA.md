# Visible equipment #309 — native QA at6b3980a6

Exact tracked source:6b3980a6420cba2cd58bf70bf1cda1a2133c2d6c. The normal production build was served at5201 through Vite preview. Its About/build metadata identifies this full source commit and `dirty: true` because an untracked output/native-combat-equipment-309 qualification workbench remains; tracked source was clean before and after both successful native runs. No application source was changed during final native QA.

## Results

| Check | Result / evidence |
| --- | --- |
| Real crafted source fixtures | PASS13. Fresh current-v2 seed72 / prepared island195, actual public hide-bearing slaughter and Smith/Leatherworker targets, real time/costs, individual allocations before paid scouting/Recon/Pillage. Exact save roundtrips and source hashes start/end passed. |
| Desktop individual allocations and normal Character Card | PASS. Bothwood, spear-only, leather-shield-only and neither; UI clear/reassign returns stored stock exactly without Materials/time drift. Opening portraits is Core-read-only. |
| Normal field tunic and source props | PASS. All4actual travellers have the fitted generic tunic/low shoes, no hat or occupational tool, correct own real module IDs. Male/female hair/beard remain. Three actual camera-sidecar angles and real paired field Character Card captured. |
| Native coarse-pointer landscape | PASS.844x390 Chrome touch emulation, actual file import and public Show group at real on-site contact. Physical Safari is not tested. |
| Final functional run | PASS5/5 scenarios; zero page errors, failed requests or HTTP error responses. native-6b3980a6-1794504080173/report.json. |
| Paired resource/timing measurement | PASS as measurement, not a performance target. Exact same ordinary camera matrix after View settlement→Show group (initialZoom62),10rendered residents,0ticks, no recording,20sparse samples percase plus native rolling diagnostics. native-6b3980a6-1794504313666/report.json and both raw exported JSONs. |
| Physical iPhone, thermals, long sessions | NOT TESTED; owner combined combat/offense QA remains pending. |
| Combat action poses | NOT IN THIS SLICE; #310 follows on the same rig. |

Source props remain preview/owner-fit-review-pending assets. Native captures show connected props and no obvious detached hand module, but this is not whole-garment penetration certification or owner acceptance for every body/pose.

## Paired measurement

No-equipment vs actual4personalmodules across3people:221→229main+shadow calls;5,279,282→5,303,542triangles (+24,260, exactly two passes of12,130prop triangles); geometry124→128; textures118→124; programs61→61. Camera matrix maximum delta0. Both samples are Paused with no Core ticks. Two fresh native contexts were used and closed.

Existing rolling diagnostics: CPUmean10.57→12.56ms, CPU p9513.30→16.20ms; valid latest GPUquery71.71→77.95ms;13.30→12.67fps. This is one pair in one order on headless Chrome157.0.8103.52. Other Codex heavy test/build jobs were held for the96.8second load/sample window; ambient OS load was not controlled. Sparse stability last-frame samples are separate from the rolling CPU distribution. No causal significance, target-FPS pass, physical-device or thermal conclusion is inferred.

## Reproduction

Use a clean tracked checkout of the exact source pin with dependencies installed and the normal production build prepared. Do not modify source while the guard is active.

- Set QA_GO to the full commit and run prepare-native-fixtures.mjs from this directory's project root. It preserves the exact executed script and hashes in fixtures-6b3980a6/.
- Serve the production build on5201. Set QA_ORIGIN=http://127.0.0.1:5201.
- For functional checks set QA_SKIP_PERF=1 and run check-native.mjs.
- For the separate matched measurement set QA_SKIP_FUNCTIONAL=1, clear QA_SKIP_PERF, and run check-native.mjs while other heavy checks are held.
- The browser owns new private contexts; no user tabs or campaign storage are accessed.

The13fixtures also include genuine five- and forty-tick-before-contact replays for #310. The geared run has no organic casualty: four real exchanges, defender withdrawal and actual homecoming. The genuine #308 unarmed casualty checkpoint remains a separate factual scenario; no death outcome was inserted into these files.

## Retained failed/preliminary attempts

- Native9755initialdevserver attempt: server acceptedTCP but did not serve even a static branding asset. Root5200 still returned200. Switched to the normal production preview, which served successfully; no application code changed.
- Initial fixture order enabled discovery after years of crafting. The public contract correctly retained a historical world; moved fresh physical discovery initialization before time advances.
- First production fixture lacked the two existing player migrations. Added ordinary UseSeasonalWeatherProduction and UseCulturalOccasions at founding rather than stripping/massaging import parity assertions.
- Harness used a string expectation for the existing clothing diagnostic object; corrected to public clothing.id/assets and strengthened actual module checks.
- One native run was interrupted because root corrected real legacy optional-field contract failures in #309. Preliminary9755captures remain marked interrupted, not final acceptance.
- Final6b first strengthened harness assumed an empty optional selectedAssets.equipmentItems array for an unarmed person. The restored legacy contract correctly omits that key; normalize absence to no items and assert the scalar equipment is null. Actual nonempty module arrays remain exact assertions.

All failures/raw reports and preliminary capture folders remain in the local workbench. They are not represented as passing final evidence. Browser tmp/profile directories must not be packaged. Original source models are not part of this QA artifact set.
