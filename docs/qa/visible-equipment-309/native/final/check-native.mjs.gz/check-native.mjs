import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = process.cwd(), pin = String(process.env.QA_GO || '');
const git = 'C:/Users/Devoteam/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe';
assert.match(pin, /^[a-f0-9]{40}$/);
assert.equal(execFileSync(git, ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), pin);
assert.equal(execFileSync(git, ['status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8' }).trim(), '');
const fixtures = JSON.parse(await readFile(process.env.QA_FIXTURES ||
    join(root, 'scratch/equipment-309/fixtures-' + pin.slice(0, 8), 'report.json'), 'utf8'));
assert.equal(fixtures.status, 'passed');
assert.equal(fixtures.source.head, pin);
for (const item of fixtures.fixtures) assert.equal(createHash('sha256').update(await readFile(item.path)).digest('hex'), item.sha256);
const { chromium } = createRequire(import.meta.url)(
    'C:/Users/Devoteam/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const output = resolve(root, 'scratch/equipment-309/native-' + pin.slice(0, 8) + '-' + Date.now());
await mkdir(join(output, 'tmp'), { recursive: true });
await writeFile(join(output, 'executed-script.mjs'), await readFile(fileURLToPath(import.meta.url)));
process.env.TEMP = process.env.TMP = join(output, 'tmp');
const origin = process.env.QA_ORIGIN || 'http://127.0.0.1:5201';
const report = { status: 'running', source: { head: pin }, origin, startedAt: new Date().toISOString(),
    scenarios: [], captures: [], performance: [], errors: [], requestFailures: [], badResponses: [],
    limits: 'Isolated native Chrome desktop and coarse-pointer touch emulation. Saved camera views and ordinary public UI only. Diagnostic timings are workstation estimates, with no screen recording during paired samples; not physical iPhone/Safari or thermal acceptance. Actual gear remains owner-fit-review preview.' };
const browser = await chromium.launch({ headless: true, chromiumSandbox: true,
    executablePath: 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
    args: ['--no-proxy-server', '--mute-audio'] });
report.chrome = browser.version();
const key = 'pillagers.fjord-play.active.v1';
const fixture = name => { const item = fixtures.fixtures.find(item => item.name === name); assert.ok(item, name); return item; };
let page, context, mode;
const core = () => page.evaluate(key => JSON.parse(sessionStorage.getItem(key)).fjord.campaign, key);
const dataset = name => page.locator('#fjord-canvas').getAttribute('data-' + name).then(JSON.parse);
const press = locator => mode.touch ? locator.tap() : locator.click();
async function shot(name) {
    const path = join(output, mode.name + '-' + name + '.png');
    await page.screenshot({ path });
    report.captures.push({ name, mode: mode.name, path, camera: await dataset('camera') });
}
async function ready() {
    const canvas = page.locator('#fjord-canvas[data-ready="true"]');
    const proceed = page.locator('[data-entry="continue"]');
    await canvas.or(proceed).first().waitFor({ timeout: 180000 });
    if (await proceed.isVisible()) await press(proceed);
    await canvas.waitFor({ timeout: 180000 });
    const chapter = page.locator('#clan-book-close');
    if (await chapter.isVisible()) await press(chapter);
    const explore = page.getByRole('button', { name: 'Explore on my own', exact: true });
    if (await explore.isVisible()) await press(explore);
    if (await page.locator('#fjord-run').getAttribute('aria-label') === 'Pause simulation') await press(page.locator('#fjord-run'));
    assert.equal(await page.locator('#fjord-run').getAttribute('aria-label'), 'Start simulation');
    await page.waitForFunction(() => !!document.querySelector('#fjord-canvas')?.dataset.rendered);
    await page.waitForTimeout(1000);
}
async function open(name, touch = false, perf = false) {
    mode = touch ? { name: 'touch-landscape', touch: true, viewport: { width: 844, height: 390 } } :
        { name: 'desktop', touch: false, viewport: { width: 1440, height: 900 } };
    context = await browser.newContext({ viewport: mode.viewport, hasTouch: touch, isMobile: touch,
        deviceScaleFactor: 1, acceptDownloads: true });
    page = await context.newPage();
    page.setDefaultTimeout(30000);
    page.on('pageerror', error => report.errors.push({ fixture: name, message: error.message }));
    page.on('requestfailed', request => report.requestFailures.push({ fixture: name, url: request.url(), failure: request.failure() }));
    page.on('response', response => { if (response.status() >= 400) report.badResponses.push({ fixture: name, url: response.url(), status: response.status() }); });
    await page.goto(origin + '/fjord-play' + (perf ? '?debugPerf=1' : ''), { waitUntil: 'domcontentloaded', timeout: 180000 });
    const build = await page.locator('.entry-about .fjord-build-details pre').textContent();
    assert.ok(build.includes(pin), 'Loaded build must report the exact source pin');
    (report.loadedBuilds ??= []).push({ fixture: name, build });
    await press(page.getByRole('button', { name: 'Load game', exact: true }));
    await page.locator('#campaign-recovery input[type="file"]').setInputFiles(fixture(name).path);
    await ready();
    const expected = JSON.parse(await readFile(fixture(name).path, 'utf8')).fjord.campaign;
    assert.deepEqual(await core(), expected, 'Normal file load preserves exact Core before any user command');
    console.log(JSON.stringify({ status: 'loaded', fixture: name, mode: mode.name }));
}
async function close() { await context.close(); }
async function resident(id) {
    await press(page.getByRole('button', { name: 'Settlement residents', exact: true }));
    await page.locator('#fjord-directory [data-ui="inspect"][data-kind="persona"][data-id="' + id + '"]').click();
    const image = page.locator('.fjord-card-heading .fjord-portrait img');
    await image.waitFor();
    await page.waitForFunction(() => { const image = document.querySelector('.fjord-card-heading .fjord-portrait img'); return image?.complete && image.naturalWidth > 0; });
    return image;
}
async function focusGroup(normalDistance = false) {
    if (normalDistance) {
        await press(page.getByRole('button', { name: 'Settlement residents', exact: true }));
        await press(page.locator('#fjord-directory [data-ui="camera-home"]'));
        await page.waitForTimeout(1000);
    }
    const toggle = page.locator('[data-expedition-toggle="group-1"]');
    if (await toggle.getAttribute('aria-expanded') !== 'true') await press(toggle);
    await press(page.locator('#expedition-mode [data-expedition-action="focus"]'));
    if (await toggle.getAttribute('aria-expanded') === 'true') await press(toggle);
    await page.waitForTimeout(1500);
}
async function places() {
    const closeCard = page.locator('[data-ui="close-card"]');
    if (await closeCard.isVisible()) await press(closeCard);
    const known = page.getByRole('button', { name: 'Known places', exact: true });
    if (!await known.isVisible()) await press(page.locator('#fjord-navigation [data-surface="expeditions"]'));
    await press(known);
    await page.locator('#island-mission-panel').waitFor();
}
try {
    if (!process.env.QA_SKIP_FUNCTIONAL) {
    await open('crafted-ready-at-home');
    const before = await core();
    const rendered = await dataset('rendered');
    for (const item of fixtures.loadouts) {
        const entity = rendered.find(actor => actor.kind === 'persona' && actor.id === item.id);
        assert.ok(entity, 'Each actual member renders at home');
        assert.deepEqual(entity.equipment, { weapon: item.weapon, shield: item.shield });
    }
    await shot('individual-loadouts-at-home');
    const image = await resident(fixtures.memberIds[0]);
    report.portrait = { id: fixtures.memberIds[0], display: await image.boundingBox(),
        natural: await image.evaluate(node => [node.naturalWidth, node.naturalHeight]),
        sha256: createHash('sha256').update(await image.getAttribute('src')).digest('hex') };
    await shot('home-work-tool-and-shield-character-card');
    assert.deepEqual(await core(), before, 'Opening a resident portrait cannot alter Core or equipment');
    await places();
    const first = fixtures.memberIds[0];
    const select = page.locator('[data-equipment-person="' + first + '"][data-equipment-slot="shield"]');
    await select.selectOption('');
    await page.waitForFunction(({ key, id }) => JSON.parse(sessionStorage.getItem(key)).fjord.campaign.smithery.assignments[id].shield === null, { key, id: first });
    const unequipped = await core();
    assert.equal(unequipped.smithery.stored.woodenShield, before.smithery.stored.woodenShield + 1);
    assert.equal(unequipped.stocks.materials, before.stocks.materials);
    await select.selectOption('woodenShield');
    await page.waitForFunction(({ key, id }) => JSON.parse(sessionStorage.getItem(key)).fjord.campaign.smithery.assignments[id].shield === 'woodenShield', { key, id: first });
    const reequipped = await core();
    assert.deepEqual(reequipped.smithery.assignments, before.smithery.assignments);
    assert.deepEqual(reequipped.smithery.stored, before.smithery.stored);
    assert.deepEqual(reequipped.time, before.time);
    assert.equal(reequipped.stocks.materials, before.stocks.materials);
    report.scenarios.push({ name: 'Four actual loadouts, same-rig card, ordinary equipment unequip/re-equip', status: 'passed' });
    await close();

    for (const name of ['geared-view-a', 'geared-view-b', 'geared-view-c']) {
        await open(name);
        const before = await core();
        const rendered = await dataset('rendered');
        for (const item of fixtures.loadouts) {
            const entity = rendered.find(actor => actor.kind === 'persona' && actor.id === item.id);
            assert.ok(entity?.expedition, 'Each actual traveller remains in its expedition');
            assert.equal(entity.clothing.id, 'generic', 'Occupation appearance is replaced by the normal tunic');
            assert.equal(entity.clothing.assets.outfit, 'garment/meshy-grid-trial-001');
            assert.equal(entity.clothing.assets.shoes, 'garment/meshy-low-shoes-005');
            assert.equal(entity.clothing.assets.headwear, null);
            const modules = { woodenSpear: 'equipment/native-wooden-spear', woodenShield: 'equipment/native-wooden-shield', leatherShield: 'equipment/native-leather-shield' };
            assert.deepEqual(entity.clothing.assets.equipmentItems ?? [], [item.weapon, item.shield].filter(Boolean).map(item => modules[item]));
            if (!item.weapon && !item.shield) assert.equal(entity.clothing.assets.equipment, null);
        }
        const groupToggle = page.locator('[data-expedition-toggle=group-1]');
        if (await groupToggle.getAttribute('aria-expanded') === 'true') await press(groupToggle);
        await shot(name);
        if (name === 'geared-view-a') {
            const fieldImage = await resident(fixtures.memberIds[0]);
            report.fieldPortrait = { id: fixtures.memberIds[0], display: await fieldImage.boundingBox(),
                sha256: createHash('sha256').update(await fieldImage.getAttribute('src')).digest('hex') };
            await shot('field-actual-spear-shield-character-card');
            await press(page.locator('[data-ui="close-card"]'));
        }
        assert.deepEqual(await core(), before);
        report.scenarios.push({ name: 'Native actual geared departure ' + name, status: 'passed' });
        await close();
    }

    await open('actual-geared-contact', true);
    const touchBefore = await core();
    await focusGroup();
    await shot('actual-geared-contact');
    assert.deepEqual(await core(), touchBefore);
    report.scenarios.push({ name: 'Native touch-emulated landscape contact import and field wardrobe', status: 'passed' });
    await close();

    }
    if (!process.env.QA_SKIP_PERF) {
    for (const name of ['matched-no-equipment-departure', 'actual-geared-departure']) {
        await open(name, false, true);
        const before = await core();
        await focusGroup(true);
        await page.waitForTimeout(4000);
        const samples = await page.evaluate(async () => {
            const rows = [];
            for (let index = 0; index < 20; index++) {
                rows.push({ at: performance.now(), ...JSON.parse(document.querySelector('#fjord-canvas').dataset.stability) });
                await new Promise(resolve => setTimeout(resolve, 525));
            }
            return rows;
        });
        await page.locator('#performance-overlay details summary').click();
        await page.locator('[data-perf-recording]').selectOption('off');
        const downloadPromise = page.waitForEvent('download');
        await page.locator('[data-perf-export]').click();
        const download = await downloadPromise;
        const path = join(output, name + '-performance.json');
        await download.saveAs(path);
        report.performance.push({ name, samples, diagnosticExport: path,
            camera: await dataset('camera'), rendered: await dataset('rendered') });
        assert.deepEqual(await core(), before, 'Paused performance diagnostics are read-only');
        await close();
    }
    const cameraDelta = Math.max(...['world', 'projection'].flatMap(key => report.performance[0].camera[key].map((value, index) => Math.abs(value - report.performance[1].camera[key][index]))));
    report.pairedCameraMaximumDelta = cameraDelta;
    assert.ok(cameraDelta < .001, 'Paired ordinary controls settle within .001 world units / matrix coefficients');
    }
    assert.deepEqual(report.errors, []);
    assert.deepEqual(report.requestFailures, []);
    assert.deepEqual(report.badResponses, []);
    assert.equal(execFileSync(git, ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), pin);
    assert.equal(execFileSync(git, ['status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8' }).trim(), '');
    report.status = 'passed';
} catch (error) {
    report.status = 'failed'; report.error = error.stack; process.exitCode = 1;
    if (page && !page.isClosed()) { report.failureCore = await core().catch(() => null); report.failureRendered = await dataset('rendered').catch(() => null); }
    if (page && !page.isClosed()) await page.screenshot({ path: join(output, 'failure.png') }).catch(() => {});
} finally {
    await browser.close();
    report.finishedAt = new Date().toISOString();
    await writeFile(join(output, 'report.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify({ status: report.status, output, scenarios: report.scenarios.length, error: report.error?.split('\n')[0] }));
}







