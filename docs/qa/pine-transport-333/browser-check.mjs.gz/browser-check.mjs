import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { isDeepStrictEqual, parseArgs } from 'node:util';

const { values } = parseArgs({ options: {
    origin: { type: 'string', default: 'http://127.0.0.1:5207' },
    commit: { type: 'string' },
    dist: { type: 'string' },
    'pine-gltf': { type: 'string' },
    baseline: { type: 'string', default: 'D:/CodexSites/Pillagers/scratch/sites-combat-qa-333-validated-dist' },
    fixture: { type: 'string' },
    output: { type: 'string', default: './results' },
    chrome: { type: 'string', default: 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe' },
    help: { type: 'boolean', default: false },
} });
if (values.help) {
    console.log('Usage: node verify-pine-transport.mjs --commit SHA --dist PATH --pine-gltf RELATIVE_PATH [--origin URL --output PATH]. One native Chrome context; no performance comparison.');
    process.exit(0);
}
assert.ok(values.commit && values.dist && values['pine-gltf'], 'Pin the built commit, build root and actual pine derivative.');
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PILLAGERS_PLAYWRIGHT_MODULE ?? 'playwright');
const { NodeIO, getBounds } = require('@gltf-transform/core');
const { loadTypeScript } = await import('../../scripts/load-typescript.mjs');
const core = loadTypeScript(new URL('../../src/simulation/SimulationCore.ts', import.meta.url));
const { natureFootprints } = loadTypeScript(new URL('../../src/world-generation/NatureFootprints.ts', import.meta.url));
const output = resolve(values.output);
const origin = new URL(values.origin).origin;
const baselinePine = join(values.baseline, 'nature/ez-tree-pilot/pine-large.gltf');
const candidatePine = join(values.dist, values['pine-gltf']);
const fixturePath = values.fixture ?? join(values.baseline, 'qa/field-campaign.json');
const fixture = await readFile(fixturePath);
const inputBridge = JSON.parse(fixture);
const inputCore = typeof inputBridge.campaign === 'string' ? JSON.parse(inputBridge.campaign) : inputBridge.campaign;
const normalizedCore = core.applyCommand(core.applyCommand(inputCore,
    { type: 'UseSeasonalWeatherProduction' }), { type: 'UseCulturalOccasions' });
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const report = {
    status: 'RUNNING', startedAt: new Date().toISOString(), commit: values.commit,
    fixtureSha256: hash(fixture), protocol: {
        browser: values.chrome, viewport: [1366, 768], dpr: 1, reducedMotion: 'no-preference',
        httpCache: 'cleared and disabled', nativeResidents: 10, performanceComparison: false,
        pixelDecode: { premultiplyAlpha: 'none', colorSpaceConversion: 'none' },
    },
    requests: [], failedRequests: [], httpErrors: [], pageErrors: [], consoleErrors: [],
    limits: [
        'One bounded native desktop correctness observation, not a loading benchmark or physical-phone test.',
        'Scene requests are captured before explicit image verification requests. PNG requests in the later verification phase are intentional.',
        'Decoded pixels are read from ImageBitmap through an RGBA8 WebGL framebuffer, avoiding canvas2D alpha re-premultiplication.',
    ],
};
await mkdir(output, { recursive: true });
const baselineJson = JSON.parse(await readFile(baselinePine, 'utf8'));
const candidateJson = JSON.parse(await readFile(candidatePine, 'utf8'));
const pairs = candidateJson.textures.map(texture => {
    const extension = texture.extensions?.EXT_texture_webp;
    assert.ok(extension, 'Every actual pine texture must have its WebP alternative.');
    return { png: candidateJson.images[texture.source].uri,
        webp: candidateJson.images[extension.source].uri };
});
assert.equal(new Set(pairs.map(pair => pair.webp)).size, 4);
report.imagePairs = pairs;

function withoutWebp(json) {
    const result = structuredClone(json);
    result.images = result.images.slice(0, baselineJson.images.length);
    result.textures.forEach(texture => {
        if (!texture.extensions) return;
        delete texture.extensions.EXT_texture_webp;
        if (!Object.keys(texture.extensions).length) delete texture.extensions;
    });
    if (result.extensionsUsed) {
        result.extensionsUsed = result.extensionsUsed.filter(name => name !== 'EXT_texture_webp');
        if (!result.extensionsUsed.length) delete result.extensionsUsed;
    }
    return result;
}
assert.deepEqual(withoutWebp(candidateJson), baselineJson, 'Only optional image transport fields may differ.');
assert.ok(!candidateJson.extensionsRequired?.includes('EXT_texture_webp'));

async function geometrySnapshot(file) {
    const document = await new NodeIO().read(file);
    const scene = document.getRoot().listScenes()[0];
    const bounds = getBounds(scene);
    const height = bounds.max[1] - bounds.min[1];
    const center = bounds.min.map((value, index) => (value + bounds.max[index]) / 2);
    const primitives = document.getRoot().listMeshes().flatMap(mesh => mesh.listPrimitives().map(primitive => {
        const attributes = Object.fromEntries(primitive.listSemantics().map(semantic => {
            const array = primitive.getAttribute(semantic).getArray();
            return [semantic, { length: array.length,
                sha256: hash(new Uint8Array(array.buffer, array.byteOffset, array.byteLength)) }];
        }));
        const indices = primitive.getIndices()?.getArray();
        return { mesh: mesh.getName(), mode: primitive.getMode(), attributes,
            indexSha256: indices ? hash(new Uint8Array(indices.buffer, indices.byteOffset, indices.byteLength)) : null };
    }));
    const roles = Object.fromEntries(['kaykit-conifer-a', 'kaykit-conifer-b', 'kaykit-conifer-c'].map(id => {
        const scale = natureFootprints[id].height / height;
        return [id, {
            scale,
            min: [(bounds.min[0] - center[0]) * scale, 0, (bounds.min[2] - center[2]) * scale],
            max: [(bounds.max[0] - center[0]) * scale, height * scale, (bounds.max[2] - center[2]) * scale],
        }];
    }));
    return { bounds, primitives, roles };
}
report.geometry = { baseline: await geometrySnapshot(baselinePine),
    candidate: await geometrySnapshot(candidatePine) };
assert.deepEqual(report.geometry.candidate, report.geometry.baseline);
report.materialAndSamplerDefinitionsIdentical = isDeepStrictEqual(candidateJson.materials, baselineJson.materials)
    && isDeepStrictEqual(candidateJson.samplers, baselineJson.samplers);
assert.equal(report.materialAndSamplerDefinitionsIdentical, true);
report.buffers = [];
for (const buffer of baselineJson.buffers) {
    const oldBytes = await readFile(resolve(dirname(baselinePine), buffer.uri));
    const newBytes = await readFile(resolve(dirname(candidatePine), buffer.uri));
    report.buffers.push({ uri: buffer.uri, sha256: hash(oldBytes), identical: oldBytes.equals(newBytes) });
    assert.ok(oldBytes.equals(newBytes));
}

let browser;
let closing = false;
let phase = 'field-scene';
try {
    report.build = await (await fetch(origin + '/build-info.json')).json();
    assert.equal(report.build.source.commit, values.commit);
    assert.equal(report.build.source.dirty, false);
    browser = await chromium.launch({ executablePath: values.chrome, headless: true, args: ['--mute-audio'] });
    report.browserVersion = browser.version();
    const browserCDP = await browser.newBrowserCDPSession();
    report.systemInfo = await browserCDP.send('SystemInfo.getInfo');
    const context = await browser.newContext({ viewport: { width: 1366, height: 768 },
        deviceScaleFactor: 1, reducedMotion: 'no-preference', acceptDownloads: true });
    const page = await context.newPage();
    page.setDefaultTimeout(60000);
    page.on('request', request => report.requests.push({ phase, url: request.url() }));
    page.on('requestfailed', request => report.failedRequests.push({ phase, url: request.url(),
        reason: request.failure()?.errorText, duringOwnedCleanup: closing }));
    page.on('response', response => {
        if (response.status() >= 400) report.httpErrors.push({ phase, url: response.url(), status: response.status() });
    });
    page.on('pageerror', error => report.pageErrors.push(String(error)));
    page.on('console', message => { if (message.type() === 'error') report.consoleErrors.push(message.text()); });
    const cdp = await context.newCDPSession(page);
    await cdp.send('Network.enable');
    await cdp.send('Network.clearBrowserCache');
    await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
    await page.goto(origin + '/fjord-play', { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => document.querySelector('.entry-motion-layer[data-ready="true"]'),
        undefined, { timeout: 30000 });
    await page.getByRole('button', { name: /^Load game/ }).click();
    await page.locator('input[type="file"]:visible').setInputFiles({ name: 'field-campaign.json',
        mimeType: 'application/json', buffer: fixture });
    await page.getByRole('button', { name: /^Continue campaign/ }).click();
    await page.waitForFunction(() => {
        const canvas = document.querySelector('#fjord-canvas');
        if (canvas?.dataset.ready !== 'true' || document.querySelector('#island-loading')) return false;
        try {
            return JSON.parse(canvas.dataset.rendered).filter(actor => actor.kind === 'persona' && !actor.placeholder).length === 10;
        } catch { return false; }
    }, undefined, { timeout: 180000, polling: 500 });
    report.scene = await page.evaluate(() => {
        const canvas = document.querySelector('#fjord-canvas');
        const gl = canvas.getContext('webgl2');
        const debug = gl.getExtension('WEBGL_debug_renderer_info');
        return {
            rendered: JSON.parse(canvas.dataset.rendered), camera: JSON.parse(canvas.dataset.camera),
            diagnostics: JSON.parse(canvas.dataset.loadDiagnostics),
            renderer: debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : null,
            ui: { quality: document.querySelector('#fjord-quality')?.value,
                effects: document.querySelector('#fjord-effects')?.value,
                clock: document.querySelector('#fjord-run')?.textContent.trim(),
                navigation: document.querySelector('#fjord-navigation')?.textContent.replace(/\s+/g, ' ').trim() },
        };
    });
    assert.equal(report.scene.diagnostics.outcome, 'playable');
    assert.equal(report.scene.ui.quality, 'low');
    assert.match(report.scene.ui.clock, /Paused/);
    const pinePrefix = new URL('nature/ez-tree-pilot/', origin + '/').href;
    report.actualScenePineRequests = report.requests.filter(request => request.phase === 'field-scene'
        && request.url.startsWith(pinePrefix));
    const actualWebp = new Set(report.actualScenePineRequests.filter(request => /\.webp$/.test(request.url))
        .map(request => new URL(request.url).pathname.split('/').at(-1)));
    report.modernWebpRequests = [...actualWebp];
    report.originalPngSceneRequests = report.actualScenePineRequests.filter(request => /\.png$/.test(request.url));
    assert.deepEqual([...actualWebp].sort(), pairs.map(pair => pair.webp).sort());
    assert.deepEqual(report.originalPngSceneRequests, []);
    assert.ok(report.actualScenePineRequests.some(request => new URL(request.url).pathname === '/' + values['pine-gltf']));
    await page.screenshot({ path: join(output, 'field-scene.png') });

    phase = 'explicit-loader-verification';
    const chunkCandidates = [];
    for (const filename of await readdir(join(values.dist, 'assets'))) {
        if (!filename.startsWith('MeshyHuman-') || !filename.endsWith('.js')) continue;
        const bytes = await readFile(join(values.dist, 'assets', filename));
        if (bytes.includes('EXT_texture_webp') && bytes.includes('setDRACOLoader')) {
            chunkCandidates.push({ filename, sha256: hash(bytes) });
        }
    }
    assert.equal(chunkCandidates.length, 1, 'Identify the actual built shared GLTFLoader chunk.');
    report.loaderChunk = chunkCandidates[0];
    report.actualLoadedPines = await page.evaluate(async ({ chunk, original, derivative, roles }) => {
        const exports = await import(chunk);
        const Loader = Object.values(exports).find(value => typeof value === 'function'
            && value.prototype?.setDRACOLoader && value.prototype?.parse && value.prototype?.register);
        if (!Loader) throw new Error('Built GLTFLoader public methods were not found.');
        const snapshots = [];
        async function digest(array) {
            const bytes = new Uint8Array(array.buffer, array.byteOffset, array.byteLength);
            const result = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
            return Array.from(result, byte => byte.toString(16).padStart(2, '0')).join('');
        }
        for (const url of [original, derivative]) {
            const firstLoader = new Loader();
            const manager = new firstLoader.manager.constructor();
            const completed = [];
            const errors = [];
            manager.onProgress = loaded => completed.push(loaded);
            manager.onError = failed => errors.push(failed);
            const gltf = await new Loader(manager).loadAsync(url);
            gltf.scene.updateMatrixWorld(true);
            const meshes = [];
            const materials = new Map();
            const bounds = { min: [Infinity, Infinity, Infinity], max: [-Infinity, -Infinity, -Infinity] };
            gltf.scene.traverse(node => {
                if (!node.isMesh) return;
                meshes.push(node);
                const position = node.geometry.getAttribute('position');
                const point = node.position.clone();
                for (let index = 0; index < position.count; index++) {
                    point.set(position.getX(index), position.getY(index), position.getZ(index))
                        .applyMatrix4(node.matrixWorld);
                    point.toArray().forEach((value, axis) => {
                        bounds.min[axis] = Math.min(bounds.min[axis], value);
                        bounds.max[axis] = Math.max(bounds.max[axis], value);
                    });
                }
                for (const material of Array.isArray(node.material) ? node.material : [node.material]) {
                    materials.set(material.uuid, material);
                }
            });
            const geometry = [];
            for (const mesh of meshes) {
                const attributes = {};
                for (const [name, attribute] of Object.entries(mesh.geometry.attributes)) {
                    attributes[name] = { count: attribute.count, itemSize: attribute.itemSize,
                        normalized: attribute.normalized, sha256: await digest(attribute.array) };
                }
                geometry.push({ name: mesh.name, attributes,
                    indicesSha256: mesh.geometry.index ? await digest(mesh.geometry.index.array) : null });
            }
            const loadedMaterials = [];
            const maps = [];
            for (const material of materials.values()) {
                const materialIndex = gltf.parser.associations.get(material)?.materials;
                if (!Number.isInteger(materialIndex)) throw new Error('Missing actual material association.');
                const definition = gltf.parser.json.materials[materialIndex];
                const expected = [
                    ['map', definition.pbrMetallicRoughness?.baseColorTexture?.index],
                    ['normalMap', definition.normalTexture?.index],
                    ['roughnessMap', definition.pbrMetallicRoughness?.metallicRoughnessTexture?.index],
                    ['metalnessMap', definition.pbrMetallicRoughness?.metallicRoughnessTexture?.index],
                ].filter(([, index]) => Number.isInteger(index));
                const parameters = {};
                for (const [slot, expectedIndex] of expected) {
                    const texture = material[slot];
                    const actualIndex = texture && gltf.parser.associations.get(texture)?.textures;
                    if (!texture || actualIndex !== expectedIndex || !(texture.image?.width > 0)
                        || !(texture.image?.height > 0)) {
                        throw new Error('Missing or incorrect actual texture: ' + material.name + '/' + slot);
                    }
                    const textureDefinition = gltf.parser.json.textures[expectedIndex];
                    const selectedImage = textureDefinition.extensions?.EXT_texture_webp?.source
                        ?? textureDefinition.source;
                    const expectedSource = new URL(gltf.parser.json.images[selectedImage].uri, url).href;
                    if (!completed.includes(expectedSource)) {
                        throw new Error('Selected material image did not complete: ' + expectedSource);
                    }
                    const image = { width: texture.image.width, height: texture.image.height };
                    maps.push({ material: material.name, slot, textureIndex: actualIndex,
                        expectedSource, ...image });
                    parameters[slot] = { ...image, colorSpace: texture.colorSpace, flipY: texture.flipY,
                        wrapS: texture.wrapS, wrapT: texture.wrapT, magFilter: texture.magFilter,
                        minFilter: texture.minFilter, channel: texture.channel };
                }
                loadedMaterials.push({ index: materialIndex, name: material.name, type: material.type,
                    color: material.color.toArray(), roughness: material.roughness, metalness: material.metalness,
                    alphaTest: material.alphaTest, transparent: material.transparent, side: material.side,
                    normalScale: material.normalScale.toArray(), maps: parameters });
            }
            const height = bounds.max[1] - bounds.min[1];
            const center = bounds.min.map((value, axis) => (value + bounds.max[axis]) / 2);
            const normalizedRoles = Object.fromEntries(Object.entries(roles).map(([id, roleHeight]) => {
                const scale = roleHeight / height;
                return [id, { scale,
                    min: [(bounds.min[0] - center[0]) * scale, 0, (bounds.min[2] - center[2]) * scale],
                    max: [(bounds.max[0] - center[0]) * scale, height * scale,
                        (bounds.max[2] - center[2]) * scale] }];
            }));
            snapshots.push({ url, geometry, bounds, normalizedRoles, materials: loadedMaterials,
                maps, completed, errors });
        }
        return snapshots;
    }, { chunk: origin + '/assets/' + report.loaderChunk.filename,
        original: origin + '/nature/ez-tree-pilot/pine-large.gltf',
        derivative: origin + '/' + values['pine-gltf'],
        roles: Object.fromEntries(['kaykit-conifer-a', 'kaykit-conifer-b', 'kaykit-conifer-c']
            .map(id => [id, natureFootprints[id].height])) });
    const [loadedOriginal, loadedDerivative] = report.actualLoadedPines;
    for (const key of ['geometry', 'bounds', 'normalizedRoles', 'materials']) {
        assert.deepEqual(loadedDerivative[key], loadedOriginal[key], 'Actual loaded pine parity: ' + key);
    }
    assert.deepEqual(loadedOriginal.errors, []);
    assert.deepEqual(loadedDerivative.errors, []);
    assert.equal(loadedDerivative.maps.length, 5, 'Bark base/normal/roughness/metalness and leaves maps must all exist.');

    phase = 'explicit-pixel-verification';
    report.pixelPairs = await page.evaluate(async ({ pairs, base }) => {
        const canvas = new OffscreenCanvas(1, 1);
        const gl = canvas.getContext('webgl2', { alpha: true, premultipliedAlpha: false, antialias: false });
        if (!gl) throw new Error('A WebGL2 framebuffer is required for nonpremultiplied bitmap readback.');
        const texture = gl.createTexture();
        const framebuffer = gl.createFramebuffer();
        const rows = [];
        async function imagePixels(uri) {
            const response = await fetch(base + uri);
            if (!response.ok) throw new Error('Image verification failed: ' + response.status + ' ' + uri);
            const bitmap = await createImageBitmap(await response.blob(),
                { premultiplyAlpha: 'none', colorSpaceConversion: 'none' });
            gl.bindTexture(gl.TEXTURE_2D, texture);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
            gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
            gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, gl.NONE);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, gl.RGBA, gl.UNSIGNED_BYTE, bitmap);
            gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
            gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
            if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error('Incomplete bitmap framebuffer.');
            const pixels = new Uint8Array(bitmap.width * bitmap.height * 4);
            gl.readPixels(0, 0, bitmap.width, bitmap.height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
            const error = gl.getError();
            if (error !== gl.NO_ERROR) throw new Error('Bitmap readback GL error: ' + error);
            const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', pixels));
            const row = { uri, width: bitmap.width, height: bitmap.height,
                rgbaSha256: Array.from(digest, byte => byte.toString(16).padStart(2, '0')).join('') };
            bitmap.close();
            return row;
        }
        try {
            for (const pair of pairs) rows.push({ png: await imagePixels(pair.png), webp: await imagePixels(pair.webp) });
            return rows;
        } finally {
            gl.deleteTexture(texture);
            gl.deleteFramebuffer(framebuffer);
            gl.getExtension('WEBGL_lose_context')?.loseContext();
        }
    }, { pairs, base: pinePrefix });
    for (const pair of report.pixelPairs) {
        assert.equal(pair.png.width, pair.webp.width);
        assert.equal(pair.png.height, pair.webp.height);
        assert.equal(pair.png.rgbaSha256, pair.webp.rgbaSha256);
    }
    phase = 'public-export';
    await page.locator('#fjord-menu > summary').click();
    const saveSection = page.locator('#fjord-menu details[data-menu-section]')
        .filter({ has: page.locator('#fjord-export') });
    if (!await saveSection.evaluate(element => element.open)) await saveSection.locator(':scope > summary').click();
    const downloadPromise = page.waitForEvent('download');
    await page.locator('#fjord-export').click();
    const download = await downloadPromise;
    assert.equal(await download.failure(), null);
    await download.saveAs(join(output, 'exported-campaign.json'));
    const savedBridge = JSON.parse(await readFile(join(output, 'exported-campaign.json'), 'utf8'));
    const savedCore = typeof savedBridge.campaign === 'string' ? JSON.parse(savedBridge.campaign) : savedBridge.campaign;
    report.coreParity = { exactAfterPublicCompatibilityCommands: isDeepStrictEqual(savedCore, normalizedCore),
        time: savedCore.time, rngState: savedCore.rngState, stocks: savedCore.stocks };
    assert.deepEqual(savedCore, normalizedCore);
    assert.deepEqual(report.httpErrors, []);
    assert.deepEqual(report.pageErrors, []);
    assert.deepEqual(report.consoleErrors, []);
    report.status = 'PASS';
} catch (error) {
    report.status = 'FAILED';
    report.failure = { message: String(error), stack: error.stack };
    process.exitCode = 1;
} finally {
    closing = true;
    await browser?.close().catch(() => {});
    report.finishedAt = new Date().toISOString();
    await writeFile(join(output, 'pine-transport-browser.json'), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({ status: report.status, output, failure: report.failure?.message,
        renderer: report.scene?.renderer, webp: report.modernWebpRequests, pixelPairs: report.pixelPairs?.length,
        coreParity: report.coreParity, failedRequests: report.failedRequests }));
}
