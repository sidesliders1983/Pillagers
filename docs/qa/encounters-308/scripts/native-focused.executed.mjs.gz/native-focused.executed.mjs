import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const pin = String(process.env.QA_GO ?? '');
assert.match(pin, /^[a-f0-9]{40}$/, 'HOLD: exact root source pin is required');
const git = 'C:/Users/Devoteam/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe';
assert.equal(execFileSync(git, ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), pin);
assert.equal(execFileSync(git, ['status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8' }).trim(), '');
const directory = fileURLToPath(new URL('./', import.meta.url));
const manifestPath = process.env.QA_FIXTURES || join(directory, 'production-final', 'browser-fixtures.json');
const fixtures = JSON.parse(await readFile(manifestPath, 'utf8'));
for (const item of fixtures.fixtures) item.path = resolve(dirname(manifestPath), item.path);
assert.equal(fixtures.status, 'passed');
assert.equal(fixtures.source.head, pin);
for (const item of fixtures.fixtures) {
    const data = await readFile(item.path);
    assert.equal(createHash('sha256').update(data).digest('hex'), item.sha256);
}
const origin = process.env.QA_ORIGIN || 'http://127.0.0.1:5200';
const { chromium } = createRequire(import.meta.url)(process.env.PLAYWRIGHT_MODULE ||
    'C:/Users/Devoteam/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const output = join(directory, 'native-' + pin.slice(0, 8) + '-' + Date.now());
await mkdir(join(output, 'tmp'), { recursive: true });
const executedScript = await readFile(fileURLToPath(import.meta.url));
await writeFile(join(output, 'executed-script.mjs'), executedScript);
const executedScriptSha256 = createHash('sha256').update(executedScript).digest('hex');
process.env.TEMP = process.env.TMP = join(output, 'tmp');
const report = { status: 'running', source: fixtures.source, origin, fixtures: manifestPath, executedScriptSha256,
    startedAt: new Date().toISOString(), scenarios: [], screenshots: [], recordings: [], errors: [],
    requestFailures: [], badResponses: [],
    scope: 'Native Chrome desktop + coarse-pointer touch emulation, real public file import/UI commands and ordinary clock continuation on a BakedCatalog production island.',
    limits: 'Physical iPhone Safari remains pending. Funded starting stocks and quiet domestic mortality/fertility/partnership isolate default on-site combat. No actors, knowledge, casualty outcomes or geometry are injected. No performance or balance approval is claimed.' };
const browser = await chromium.launch({ headless: true, chromiumSandbox: true,
    args: ['--no-proxy-server', '--mute-audio'],
    executablePath: process.env.QA_CHROME || 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe' });
report.chrome = browser.version();
report.visualFollowupOnly = process.env.QA_VISUAL_ONLY === '1';
const key = 'pillagers.fjord-play.active.v1';
let mode, page, openedFixture;
const pending = new Set();
const press = locator => mode.touch ? locator.tap() : locator.click();
const core = () => page.evaluate(key => JSON.parse(sessionStorage.getItem(key)).fjord.campaign, key);
const active = state => Object.values(state.world.spatial?.missions ?? {}).at(-1);
const fixture = name => { const item = fixtures.fixtures.find(item => item.name === name); assert.ok(item, name); return item; };
async function shot(name) {
    const path = join(output, mode.name + '-' + name + '.jpg');
    await page.screenshot({ path, quality: 87 });
    report.screenshots.push(path);
}
async function pause() {
    if (await page.locator('#fjord-run').getAttribute('aria-label') === 'Pause simulation')
        await press(page.locator('#fjord-run'));
    assert.equal(await page.locator('#fjord-run').getAttribute('aria-label'), 'Start simulation');
}
async function ready() {
    const canvas = page.locator('#fjord-canvas[data-ready="true"]');
    const proceed = page.locator('[data-entry="continue"]');
    await canvas.or(proceed).first().waitFor({ timeout: 180000 });
    if (await proceed.isVisible()) await press(proceed);
    await canvas.waitFor({ timeout: 180000 });
    const chapter = page.locator('#clan-book-close');
    if (await chapter.isVisible()) await press(chapter);
    const explore = page.getByRole('button', { name: 'Explore on my own', exact: true });
    if (await explore.isVisible()) await press(explore);
    await pause();
    await page.waitForFunction(() => !!document.querySelector('#fjord-canvas')?.dataset.rendered);
}
async function close(context) {
    const video = page.video();
    await context.close();
    if (video) report.recordings.push({ mode: mode.name, fixture: openedFixture, path: await video.path() });
}
async function open(name) {
    openedFixture = name;
    const context = await browser.newContext({ viewport: mode.viewport, hasTouch: mode.touch,
        isMobile: mode.touch, acceptDownloads: true,
        ...(['three-survivors-near-home', 'actual-contact'].includes(name) ? { recordVideo: { dir: join(output, 'video'), size: mode.viewport } } : {}) });
    page = await context.newPage();
    page.setDefaultTimeout(30000);
    page.on('pageerror', error => report.errors.push({ mode: mode.name, error: error.message }));
    page.on('request', request => pending.add(request.url()));
    page.on('requestfinished', request => pending.delete(request.url()));
    page.on('requestfailed', request => { pending.delete(request.url());
        report.requestFailures.push({ url: request.url(), failure: request.failure() }); });
    page.on('response', response => { if (response.status() >= 400)
        report.badResponses.push({ url: response.url(), status: response.status() }); });
    await page.goto(origin + '/fjord-play', { waitUntil: 'domcontentloaded', timeout: 180000 });
    const loadedBuild = await page.locator('.entry-about .fjord-build-details pre').textContent();
    assert.ok(loadedBuild.includes(pin), 'The loaded browser bundle must identify the exact source pin');
    report.loadedBuildIdentity = loadedBuild;
    await press(page.getByRole('button', { name: 'Load game', exact: true }));
    await page.locator('#campaign-recovery input[type="file"]').setInputFiles(fixture(name).path);
    await ready();
    return context;
}
async function places() {
    if (await page.locator('#island-mission-panel').isVisible()) return;
    const known = page.getByRole('button', { name: 'Known places', exact: true });
    if (!await known.isVisible()) await press(page.locator('#fjord-navigation [data-surface="expeditions"]'));
    await press(known);
    await page.locator('#island-mission-panel').waitFor();
}
async function worldShot(name) {
    const before = await core();
    const workspaceClose = page.locator('#fjord-workspace [data-ui="close-workspace"]');
    if (await workspaceClose.isVisible()) await press(workspaceClose);
    const shortcut = page.locator('[data-expedition-toggle="' + active(before).groupId + '"]');
    const focus = page.locator('#expedition-mode [data-expedition-action="focus"]');
    if (!await focus.isVisible()) await press(shortcut);
    await focus.waitFor();
    await press(focus);
    if (await shortcut.getAttribute('aria-expanded') === 'true') await press(shortcut);
    assert.equal(await page.locator('#expedition-mode').isVisible(), false);
    await page.waitForTimeout(1200);
    await shot(name);
    assert.deepEqual(await core(), before, 'Camera focus and collapsing the overlay are read-only');
}
async function quoteBackDispatchRecall() {
    const context = await open('ready-at-home');
    await places();
    const before = await core();
    const priorities = page.locator('[data-island-cargo-options]');
    if (await priorities.getAttribute('open') === null) await press(priorities.locator('summary'));
    for (const cargo of ['Materials', 'Cattle', 'People']) await page.locator('[data-cargo="' + cargo + '"]').uncheck();
    await page.locator('[data-cargo="Food"]').check();
    await press(page.locator('[data-island-type="Pillage"]'));
    const dialog = page.locator('#island-mission-dialog');
    await dialog.waitFor();
    const quote = await page.locator('#island-mission-summary').innerText();
    assert.match(quote, /on.site|On.site|contact|Contact/);
    assert.ok(quote.includes(fixtures.primary.foodCost + ' Food'));
    assert.deepEqual(await core(), before, 'Reviewing the quote is read-only');
    await shot('default-pillage-quote');
    await press(dialog.locator('[data-island-cancel]'));
    assert.deepEqual(await core(), before, 'Back does not spend provisions, reveal knowledge or move bodies');
    await press(page.locator('[data-island-type="Pillage"]'));
    await press(dialog.locator('[data-island-confirm]'));
    const dispatched = await core(), mission = active(dispatched);
    assert.equal(mission.memberIds.length, 4);
    assert.equal(dispatched.stocks.food, before.stocks.food - fixtures.primary.foodCost);
    assert.equal(mission.task.type, 'Pillage');
    assert.equal(Object.keys(dispatched.world.spatial.missions).length, Object.keys(before.world.spatial.missions).length + 1);
    await shot('four-real-residents-dispatched');
    await places();
    await press(page.getByRole('button', { name: 'Return group home', exact: true }));
    const recalled = await core();
    assert.equal(active(recalled).status, 'Returned');
    assert.equal(active(recalled).outcome, 'Cancelled');
    assert.equal(recalled.stocks.food, dispatched.stocks.food);
    assert.equal(recalled.events.some(event => event.type === 'PersonaDied' && event.details?.missionId === mission.id), false);
    report.scenarios.push({ mode: mode.name, kind: 'real-quote-Back-paid-dispatch-immediate-recall',
        missionId: mission.id, foodBefore: before.stocks.food, foodPaid: fixtures.primary.foodCost });
    await close(context);
}
async function actualContactWithdrawal() {
    const context = await open('actual-contact');
    const before = await core(), mission = active(before);
    const entry = before.world.encounters.records[mission.task.encounterRules.encounterId];
    assert.equal(entry.phase, 'engaging');
    assert.ok(entry.defenderIds.length > 0);
    await places();
    assert.match(await page.locator('#island-mission-panel').innerText(), /Engagement in progress/);
    await shot('actual-observed-contact');
    await press(page.getByRole('button', { name: 'Withdraw group', exact: true }));
    const requested = await core(), withdrawing = active(requested);
    assert.equal(withdrawing.task.encounterRules.phase, 'withdrawing');
    assert.notEqual(withdrawing.status, 'Returning');
    assert.equal(withdrawing.travelled, mission.travelled, 'Withdrawal cannot move bodies at command time');
    assert.equal(requested.stocks.food, before.stocks.food);
    await shot('bounded-disengagement-requested');
    await press(page.locator('#fjord-run'));
    await page.waitForFunction(key => {
        const mission = Object.values(JSON.parse(sessionStorage.getItem(key)).fjord.campaign.world.spatial.missions).at(-1);
        return mission.status === 'Returning' || mission.status === 'Returned' || mission.status === 'Lost';
    }, key, { timeout: 60000, polling: 100 });
    await pause();
    const after = await core(), final = active(after);
    assert.ok(after.time.winter * 1000 + after.time.tick >= before.time.winter * 1000 + before.time.tick +
        mission.task.encounterRules.policy.disengageTicks);
    await shot('physical-withdrawal-transition');
    report.scenarios.push({ mode: mode.name, kind: 'actual-contact-real-bounded-withdrawal', missionId: mission.id,
        observedDefenders: entry.defenderIds.length, beforeTime: before.time, afterTime: after.time,
        status: final.status, phase: final.task.encounterRules.phase });
    await close(context);
}
async function actualDefaultCombat() {
    const context = await open('actual-contact');
    const before = await core(), mission = active(before);
    assert.equal(mission.memberIds.filter(id => before.personas[id].deathWinter === null).length, 4);
    await places();
    assert.match(await page.locator('#island-mission-panel').innerText(), /4 active crew.*0 recorded loss/);
    await worldShot('four-real-crew-before-default-combat');
    await press(page.locator('#fjord-run'));
    await page.waitForFunction(({ key, missionId }) => JSON.parse(sessionStorage.getItem(key)).fjord.campaign.events
        .some(event => event.type === 'PersonaDied' && event.details?.cause === 'Combat' &&
            event.details?.missionId === missionId), { key, missionId: mission.id }, { timeout: 60000, polling: 100 });
    await pause();
    const after = await core();
    const deaths = after.events.filter(event => event.type === 'PersonaDied' && event.details?.cause === 'Combat' &&
        event.details?.missionId === mission.id);
    assert.equal(deaths.length, 1);
    assert.equal(mission.memberIds.filter(id => after.personas[id].deathWinter === null).length, 3);
    assert.equal(deaths[0].personaId, fixtures.primary.deaths[0].personaId);
    assert.deepEqual(deaths[0].time, fixtures.primary.deaths[0].time);
    assert.equal(after.events.some(event => event.type === 'ExpeditionReturned' && event.details?.missionId === mission.id), false);
    await worldShot('three-real-crew-after-on-site-death');
    await places();
    assert.match(await page.locator('#island-mission-panel').innerText(), /3 active crew.*1 recorded loss/);
    await shot('actual-death-before-homecoming');
    const corePath = join(output, mode.name + '-actual-default-combat.core.json');
    await writeFile(corePath, JSON.stringify(after));
    report.scenarios.push({ mode: mode.name, kind: 'real-clock-four-crew-one-on-site-death-three-survivors',
        missionId: mission.id, beforeTime: before.time, afterTime: after.time,
        death: { id: deaths[0].id, personaId: deaths[0].personaId, time: deaths[0].time }, corePath });
    await close(context);
}

async function inTransit() {
    const context = await open('actual-cargo-in-transit');
    const before = await core(), mission = active(before), manifest = mission.task.encounterRules.manifest;
    assert.equal(manifest.deliveredAt, null);
    assert.ok(manifest.slots.some(slot => slot.status === 'held'));
    await places();
    assert.match(await page.locator('#island-mission-panel').innerText(), /In transit.*unavailable in home stocks/);
    await shot('actual-cargo-unavailable-at-home');
    await worldShot('actual-production-world-after-contact');
    assert.deepEqual(await core(), before);
    report.scenarios.push({ mode: mode.name, kind: 'actual-captured-stock-read-only-in-transit', missionId: mission.id,
        captureEventId: manifest.captureEventId, slotCount: manifest.slots.length });
    await close(context);
}
async function threeSurvivorsHome() {
    const context = await open('three-survivors-near-home');
    const before = await core(), mission = active(before);
    const deaths = before.events.filter(event => event.type === 'PersonaDied' &&
        event.details?.missionId === mission.id && event.details?.cause === 'Combat');
    assert.equal(deaths.length, 1);
    assert.equal(mission.status, 'Returning');
    assert.equal(mission.memberIds.filter(id => before.personas[id].deathWinter === null).length, 3);
    await worldShot('three-survivors-physically-returning');
    await places();
    assert.match(await page.locator('#island-mission-panel').innerText(), /3 active crew.*1 recorded loss/);
    await press(page.locator('#fjord-workspace [data-ui="close-workspace"]'));
    await shot('three-survivors-before-home-clock');
    await press(page.locator('#fjord-run'));
    await page.waitForFunction(key => Object.values(JSON.parse(sessionStorage.getItem(key)).fjord.campaign
        .world.spatial.missions).at(-1).status === 'Returned', key, { timeout: 60000, polling: 100 });
    await pause();
    const after = await core(), returned = active(after);
    assert.equal(returned.task.result.survivorIds.length, 3);
    assert.deepEqual(returned.task.result.casualtyIds, [deaths[0].personaId]);
    assert.equal(after.events.filter(event => event.type === 'MissionCargoDelivered' &&
        event.details?.missionId === mission.id).length, 1);
    assert.equal(after.events.filter(event => event.type === 'ExpeditionReturned' &&
        event.details?.missionId === mission.id).length, 1);
    await shot('three-survivors-arrived-world');
    await places();
    await shot('three-survivors-genuine-homecoming');
    await press(page.locator('#fjord-attention'));
    await press(page.locator('#fjord-attention-feed [data-attention-action="all"]').first());
    const death = page.locator('#fjord-attention-feed [data-attention-action="event"][data-attention-id="' + deaths[0].id + '"]');
    await death.waitFor();
    await press(death);
    assert.match(await page.locator('#fjord-attention-feed').innerText(), /died in combat/);
    await shot('actual-combat-history-source');
    assert.deepEqual(await core(), after, 'Reading personal/source history never changes Core');
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 180000 });
    await ready();
    assert.deepEqual(await core(), after, 'Reload neither repeats death nor delivers cargo again');
    report.scenarios.push({ mode: mode.name, kind: 'three-real-survivors-physical-homecoming-history-reload',
        missionId: mission.id, combatDeath: { eventId: deaths[0].id, personaId: deaths[0].personaId, time: deaths[0].time },
        survivorIds: returned.task.result.survivorIds, deliveredFood: returned.task.result.food,
        returnedAt: returned.returnedAt });
    await close(context);
}
try {
    mode = { name: 'desktop', viewport: { width: 1440, height: 900 }, touch: false };
    if (process.env.QA_VISUAL_ONLY !== '1') {
        await quoteBackDispatchRecall();
        await actualContactWithdrawal();
    }
    await actualDefaultCombat();
    if (process.env.QA_VISUAL_ONLY !== '1') await inTransit();
    await threeSurvivorsHome();
    mode = { name: 'touch-landscape', viewport: { width: 844, height: 390 }, touch: true };
    await quoteBackDispatchRecall();
    await actualContactWithdrawal();
    await actualDefaultCombat();
    await threeSurvivorsHome();
    assert.deepEqual(report.errors, []);
    assert.deepEqual(report.badResponses, []);
    assert.deepEqual(report.requestFailures, []);
    report.status = 'passed';
} catch (error) {
    report.status = 'failed'; report.failure = String(error.stack ?? error); process.exitCode = 1;
    if (page && !page.isClosed()) {
        report.pendingRequests = [...pending];
        report.document = await Promise.race([
            page.evaluate(() => ({ readyState: document.readyState, body: document.body?.innerText, url: location.href })),
            new Promise(resolve => setTimeout(() => resolve({ unavailable: 'Renderer did not answer within 5 seconds' }), 5000)),
        ]).catch(error => ({ unavailable: String(error) }));
        await shot('failure').catch(() => {});
    }
    console.error(report.failure);
} finally {
    report.finishedAt = new Date().toISOString();
    await writeFile(join(output, 'report.json'), JSON.stringify(report, null, 2));
    const pendingVideo = page?.video();
    await browser.close();
    if (pendingVideo) {
        const path = await pendingVideo.path();
        if (!report.recordings.some(item => item.path === path)) {
            report.recordings.push({ mode: mode.name, fixture: openedFixture, path, incomplete: report.status !== 'passed' });
            await writeFile(join(output, 'report.json'), JSON.stringify(report, null, 2));
        }
    }
    console.log(JSON.stringify({ status: report.status, output, scenarios: report.scenarios.length, errors: report.errors }));
}
