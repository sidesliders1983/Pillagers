import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { join, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
const root = resolve(process.env.QA_ROOT || process.cwd());
const { loadTypeScript } = await import(pathToFileURL(join(root, 'scripts/load-typescript.mjs')));

const git = 'C:/Users/Devoteam/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe';
const pin = String(process.env.QA_GO ?? '');
const head = execFileSync(git, ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
if (pin) {
    assert.match(pin, /^[a-f0-9]{40}$/);
    assert.equal(head, pin, 'Final fixture preparation requires the root source pin');
    assert.equal(execFileSync(git, ['status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8' }).trim(), '');
}
const load = name => loadTypeScript(pathToFileURL(join(root, 'src', name + '.ts')));
const core = load('simulation/SimulationCore');
const { SharedSettlement } = load('play/SharedSettlement');
const { GameplaySession } = load('gameplay-lab/GameplaySession');
const { adoptCampaignIsland, islandRecipe } = load('fjord-play/CampaignIsland');
const { campaignIslandCatalog } = load('fjord-play/BakedIslandCatalog');
const digest = value => createHash('sha256').update(value).digest('hex');
const sourceNames = ['simulation/OnSiteEncounters', 'simulation/TransitCargo', 'simulation/SimulationCore',
    'simulation/SpatialExpeditions', 'simulation/IslandMissions', 'simulation/TerritorialAwareness',
    'simulation/ResidentPresence', 'simulation/Smithery', 'fjord-play/FjordCampaign'];
const hashes = () => Object.fromEntries(sourceNames.map(name => [name,
    digest(readFileSync(join(root, 'src', name + '.ts')))]));
const sourceStart = hashes();
const directory = new URL('./' + (process.env.QA_PRODUCTION_OUTPUT ?? 'production-draft-v2') + '/', import.meta.url);
mkdirSync(directory, { recursive: true });
const report = { status: pin ? 'preparing-pinned-fixtures' : 'searching-draft-source',
    head, startedAt: new Date().toISOString(), sourceStart,
    limits: (pin ? 'Pinned fixtures; native browser verification is separate. ' : 'Draft source; not final browser evidence. ') +
        'Real unchanged BakedCatalog terrain, actual generated people and public paid journeys only. Explicit funded starting stocks and quiet natural mortality/fertility/partnership isolate combat. No actors, knowledge, casualties, bodies or geometry are injected.',
    candidates: [], sample: null };
const quiet = { mortalityBands: [{ minAge: 0, chanceBps: 0 }], fertilityChanceBps: 0, partnershipChanceBps: 0 };
const limit = Number(process.env.QA_PRODUCTION_SEEDS ?? 12);
const seedStart = Number(process.env.QA_PRODUCTION_START ?? 1);
const current = shared => shared.session.readSnapshot();
const latest = shared => Object.values(current(shared).world.spatial?.missions ?? {}).at(-1);
const command = (shared, value) => shared.session.command(value);
const tick = (shared, count = 5) => command(shared, { type: 'AdvanceTicks', ticks: count });
function wait(shared, predicate, bound = 1000) {
    for (let advanced = 0; advanced < bound && !predicate(); advanced += 5) tick(shared);
    assert.ok(predicate(), 'Actual public journey did not reach its requested checkpoint within ' + bound + ' ticks');
}
function store(shared, directory, name) {
    shared.session.setRunning(false);
    const text = shared.persist();
    const restored = SharedSettlement.restore(text, 'fjord');
    assert.equal(restored.session.saveJSON(), shared.session.saveJSON());
    assert.equal(restored.persist(), text);
    writeFileSync(new URL('./' + name + '.shared.json', directory), text);
    return { name, bytes: Buffer.byteLength(text), sha256: digest(text), time: { ...current(shared).time } };
}

const candidateSeeds = [];
const requiredBaked = process.env.QA_PRODUCTION_BAKED ? Number(process.env.QA_PRODUCTION_BAKED) : null;
for (let seed = seedStart; seed < seedStart + 4000 && candidateSeeds.length < limit; seed++) {
    if (requiredBaked === null || islandRecipe(seed, 'island-pool-v3').seed === requiredBaked) candidateSeeds.push(seed);
}
report.candidateSeeds = candidateSeeds;
for (const seed of candidateSeeds) {
    if (report.sample) break;
    const row = { seed, phase: 'baked-adoption' };
    report.candidates.push(row);
    try {
        const recipe = islandRecipe(seed, 'island-pool-v3');
        const entry = campaignIslandCatalog.entries.find(value => value.version === recipe.version && value.seed === recipe.seed);
        assert.ok(entry);
        const compressed = readFileSync(join(root, 'public' + entry.path));
        assert.equal(digest(compressed), entry.sha256);
        const canonical = gunzipSync(compressed);
        assert.equal(digest(canonical), entry.canonicalSha256);
        const { world, plan } = JSON.parse(canonical);
        adoptCampaignIsland(seed, world, plan);
        row.recipe = recipe;
        row.bakedSha256 = entry.sha256;
        const session = new GameplaySession(seed, seed, false);
        session.loadJSON(core.serializeState(core.createCampaign(seed,
            { initialFood: 2000, initialMaterials: 200 }, quiet, { enabled: false }, {}, { enabled: false }, {}, 'summer-800-v1')));
        const shared = new SharedSettlement(session, undefined, false, recipe.version);
        shared.fjord.enableDiscovery();
        const members = core.inspectWorld(current(shared)).eligible.slice(0, 4).map(person => person.id);
        assert.equal(members.length, 4);
        command(shared, { type: 'CreateExpeditionGroup', name: 'Shore party', memberIds: members });
        row.memberIds = members;
        row.phase = 'paid-physical-scouting';
        command(shared, { type: 'StartExpedition', groupId: 'group-1' });
        command(shared, { type: 'ExploreArea', groupId: 'group-1', target: world.rivalSite.center });
        wait(shared, () => Object.keys(current(shared).world.islandIntel?.sites ?? {}).length > 0, 700);
        const siteId = Object.keys(current(shared).world.islandIntel.sites)[0];
        const sighting = core.inspectSpatialExpeditions(current(shared)).missions.at(-1).position;
        const reconTarget = { kind: 'area', position: { x: sighting.x, z: sighting.z } };
        row.actualSightingPosition = reconTarget.position;
        command(shared, { type: 'RecallExpedition', groupId: 'group-1' });
        wait(shared, () => latest(shared).status === 'Returned');
        row.phase = 'paid-returned-recon';
        let knowledge;
        row.reconAttempts = 0;
        for (; row.reconAttempts < 3 && !knowledge?.settlementName; row.reconAttempts++) {
            command(shared, { type: 'DispatchIslandMission', groupId: 'group-1', target: reconTarget, mission: 'Recon' });
            wait(shared, () => latest(shared).status === 'Returned');
            assert.ok(members.every(id => current(shared).personas[id].deathWinter === null),
                'Four living actual crew must remain after the paid preparatory Recon');
            knowledge = core.inspectIslandMissions(current(shared)).sites.find(site => site.id === siteId)?.knowledge;
        }
        assert.ok(knowledge?.settlementName && knowledge?.opportunity);
        row.siteId = siteId;
        row.scoutedAt = { ...current(shared).time };
        row.phase = 'canonical-territory-adoption';
        shared.fjord.enableTerritorialAwareness();
        const seedDir = new URL('./seed-' + seed + '/', directory);
        mkdirSync(seedDir, { recursive: true });
        row.fixtures = [store(shared, seedDir, 'ready-at-home')];
        const foodBefore = current(shared).stocks.food;
        row.phase = 'default-physical-pillage';
        command(shared, { type: 'DispatchIslandMission', groupId: 'group-1', target: { kind: 'site', siteId },
            mission: 'Pillage', priorities: ['Food'] });
        row.foodCost = foodBefore - current(shared).stocks.food;
        row.fixtures.push(store(shared, seedDir, 'departed'));
        let savedContact = false, savedDeath = false, savedNearHome = false, savedCargo = false, advanced = 0;
        while (!['Returned', 'Lost', 'Stranded'].includes(latest(shared).status) && advanced < 900) {
            tick(shared, 1);
            advanced++;
            const mission = latest(shared);
            const encounter = current(shared).world.encounters?.records[mission.task.encounterRules.encounterId];
            if (encounter?.phase === 'engaging' && !savedContact) {
                row.fixtures.push(store(shared, seedDir, 'actual-contact'));
                savedContact = true;
            }
            if (!savedDeath && current(shared).events.some(event => event.type === 'PersonaDied' &&
                event.details?.missionId === mission.id && event.details?.cause === 'Combat')) {
                row.fixtures.push(store(shared, seedDir, 'after-combat-casualty'));
                savedDeath = true;
            }
            if (!savedCargo && mission.task.encounterRules.manifest?.slots.some(slot => slot.status === 'held')) {
                row.fixtures.push(store(shared, seedDir, 'actual-cargo-in-transit'));
                savedCargo = true;
            }
            if (savedDeath && !savedNearHome && mission.status === 'Returning' && mission.travelled <= 20) {
                row.fixtures.push(store(shared, seedDir, 'three-survivors-near-home'));
                savedNearHome = true;
            }
        }
        const state = current(shared), mission = latest(shared);
        const encounter = state.world.encounters?.records[mission.task.encounterRules.encounterId];
        const deaths = state.events.filter(event => event.type === 'PersonaDied' &&
            event.details?.missionId === mission.id && event.details?.cause === 'Combat');
        row.phase = 'completed-trial';
        row.status = mission.status;
        row.actualCommittedDefenders = encounter?.defenderIds.length ?? 0;
        row.actions = encounter?.exchanges.flatMap(exchange => exchange.actions).length ?? 0;
        row.encounterOutcome = encounter?.outcome ?? null;
        row.deaths = deaths.map(event => ({ eventId: event.id, personaId: event.personaId, time: event.time }));
        row.result = mission.task.result;
        row.returnedAt = mission.returnedAt;
        row.encounterPolicy = mission.task.encounterRules.policy;
        row.fixtures.push(store(shared, seedDir, 'after-journey'));
        if (mission.status === 'Returned' && deaths.length === 1 && mission.task.result.survivorIds.length === 3) {
            report.sample = { ...row, directory: fileURLToPath(seedDir) };
        }
        console.log(JSON.stringify({ seed, island: recipe.seed, status: row.status,
            defenders: row.actualCommittedDefenders, deaths: deaths.length, survivors: mission.task.result?.survivorIds.length ?? 0 }));
    } catch (error) {
        row.error = error.stack;
        console.log(JSON.stringify({ seed, phase: row.phase, error: error.message }));
    }
    writeFileSync(new URL('./report.json', directory), JSON.stringify({ ...report, sourceEnd: hashes() }, null, 2));
}
report.sourceEnd = hashes();
report.sourceUnchangedDuringRun = JSON.stringify(sourceStart) === JSON.stringify(report.sourceEnd);
report.status = report.sample && report.sourceUnchangedDuringRun && pin ? 'passed' :
    report.sample ? 'draft-sample-found' : 'bounded-search-no-sample';
if (report.status === 'passed') {
    const primary = report.sample;
    const fixtures = primary.fixtures.map(item => ({ ...item,
        path: './seed-' + primary.seed + '/' + item.name + '.shared.json' }));
    writeFileSync(new URL('./browser-fixtures.json', directory), JSON.stringify({ status: 'passed',
        source: { head: pin, sourceHashes: sourceStart }, primary, fixtures, limits: report.limits }, null, 2));
}
writeFileSync(new URL('./report.json', directory), JSON.stringify(report, null, 2));
console.log(JSON.stringify({ status: report.status, sourceUnchanged: report.sourceUnchangedDuringRun,
    candidates: report.candidates.length, sample: report.sample?.seed ?? null }));
