import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { join, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
const root = resolve(process.env.QA_ROOT || process.cwd());
const { loadTypeScript } = await import(pathToFileURL(join(root, 'scripts/load-typescript.mjs')));

const git = 'C:/Users/Devoteam/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe';
const pin = String(process.env.QA_GO ?? '');
const head = execFileSync(git, ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
if (pin) {
    if (!/^[a-f0-9]{40}$/.test(pin) || head !== pin ||
        execFileSync(git, ['status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8' }).trim())
        throw Error('Final comparison needs the exact clean root source pin');
}
const output = new URL('./' + (process.env.QA_MATRIX_OUTPUT ?? 'default-comparison') + '/', import.meta.url);
mkdirSync(output, { recursive: true });
const inputs = ['SimulationCore', 'OnSiteEncounters', 'TransitCargo', 'SpatialExpeditions',
    'TerritorialAwareness', 'ResidentPresence', 'Mortality', 'Smithery', 'IslandMissions', 'Weather'];
const hashes = () => Object.fromEntries(inputs.map(name => [name, createHash('sha256')
    .update(readFileSync(join(root, 'src/simulation', name + '.ts'))).digest('hex')]));
const sourceStart = hashes();
const core = loadTypeScript(pathToFileURL(join(root, 'src/simulation/SimulationCore.ts')));
const { encounterPolicy } = loadTypeScript(pathToFileURL(join(root, 'src/simulation/OnSiteEncounters.ts')));
const quiet = { mortalityBands: [{ minAge: 0, chanceBps: 0 }], fertilityChanceBps: 0,
    partnershipChanceBps: 0 };
const world = (() => {
    const bounds = { minX: 0, maxX: 320, minZ: 0, maxZ: 256 };
    return { waterLevel: -1,
        terrain: { bounds, spacing: 8, columns: 41, rows: 33, heights: Array(1353).fill(0) },
        navigation: { bounds, spacing: 8, columns: 41, rows: 33, cells: Array(1353).fill(true) },
        settlement: { center: { x: 64, z: 128 }, harbor: null },
        rivalSite: { version: 1, candidateId: 'encounter-rival', center: { x: 160, z: 128 },
            bounds: { minX: 128, maxX: 272, minZ: 88, maxZ: 176 }, foundations: [], buildableArea: 12672 } };
})();
const worldId = 'on-site-encounter-matched-308';
const latest = state => Object.values(state.world.spatial.missions).at(-1);
const adults = clan => Object.keys(clan.personas).sort().filter(id =>
    clan.personas[id].deathWinter === null && core.personaAge(clan, id) >= clan.mechanics.config.workAge);

function gear(clan, ids, mode) {
    const selected = mode === 'none' ? [] : mode === 'mixed' ? ids.filter((_, index) => index % 2 === 0) : ids;
    // Explicit funded QA inventory; every actual body is equipped using the public command.
    clan.smithery.stored.woodenSpear += selected.length;
    clan.smithery.stored[mode === 'full' ? 'leatherShield' : 'woodenShield'] += selected.length;
    for (const personaId of selected) {
        clan = core.applyCommand(clan, { type: 'AssignEquipment', personaId, slot: 'weapon', item: 'woodenSpear' });
        clan = core.applyCommand(clan, { type: 'AssignEquipment', personaId, slot: 'shield',
            item: mode === 'full' ? 'leatherShield' : 'woodenShield' });
    }
    return clan;
}

function fixture(seed, nearCount, mode, defenderMode = mode) {
    let state = core.initializeIslandClans(core.createCampaign(seed,
        { initialFood: 2000, initialMaterials: 200 }, quiet, { enabled: false }, {
            successBps: { Recon: 10000, Surveillance: 10000, Pillage: 6000 },
            casualtyBps: { Recon: 0, Surveillance: 0, Pillage: 1000 },
        }), world, worldId);
    const members = adults(state).slice(0, 4);
    if (members.length !== 4) throw Error('The actual generated campaign needs four adult raiders');
    state = core.applyCommand(state, { type: 'CreateExpeditionGroup', name: 'Matched shore party', memberIds: members });
    state = core.applyCommand(state, { type: 'DispatchIslandMission', groupId: 'group-1',
        target: { kind: 'area', position: { x: 128, z: 128 } }, mission: 'Recon' }, { world, worldId });
    state = core.applyCommand(state, { type: 'AdvanceTicks', ticks: 250 }, { world, worldId });
    if (!core.inspectIslandMissions(state).sites[0]?.knowledge?.settlementName)
        throw Error('The actual paid Recon must have identified the destination');
    const rivalId = state.world.island.clanId;
    let rival = state.world.targetClans[rivalId];
    const nearIds = adults(rival).slice(0, nearCount);
    if (nearIds.length !== nearCount) throw Error('Not enough actual adult responders in this seed');
    const rootHomes = Object.fromEntries(Object.keys(state.personas).sort().map((id, index) =>
        [id, { x: 48 + index % 4 * 4, z: 116 + Math.floor(index / 4) * 8 }]));
    const sourceHomes = Object.fromEntries(Object.keys(rival.personas).sort().map((id, index) => {
        const nearby = nearIds.indexOf(id);
        return [id, nearby >= 0 ? { x: 156 + nearby % 2 * 2, z: 126 + Math.floor(nearby / 2) * 2 } :
            { x: 248 + index % 4 * 4, z: 116 + Math.floor(index / 4) * 8 }];
    }));
    state = gear(state, members, mode);
    rival = gear(rival, nearIds, defenderMode);
    state.world.targetClans[rivalId] = rival;
    const context = { world, worldId, presenceSites: [
        { clanId: state.clan.id, center: world.settlement.center,
            bounds: { minX: 32, maxX: 112, minZ: 88, maxZ: 176 }, homes: rootHomes },
        { clanId: rivalId, center: world.rivalSite.center, bounds: world.rivalSite.bounds, homes: sourceHomes },
    ] };
    state = core.initializeTerritorialAwareness(state, context, { ambientRadius: 0, maxResponders: 4 });
    return { state, context, members, rivalId, nearIds, seed, nearCount, mode, defenderMode };
}

function run(setup, keep = false) {
    const before = core.serializeState(setup.state);
    let state = core.applyCommand(setup.state, { type: 'DispatchIslandMission', groupId: 'group-1',
        target: { kind: 'site', siteId: world.rivalSite.candidateId }, mission: 'Pillage', priorities: ['Food'] }, setup.context);
    let advanced = 0;
    while (!['Returned', 'Lost', 'Stranded'].includes(latest(state).status) && advanced < 700) {
        try {
            state = core.applyCommand(state, { type: 'AdvanceTicks', ticks: 5 }, setup.context);
        } catch (error) {
            const failure = new URL('./failure-seed-' + setup.seed + '-near-' + setup.nearCount +
                '-' + setup.mode + '-vs-' + setup.defenderMode + '/', output);
            mkdirSync(failure, { recursive: true });
            writeFileSync(new URL('./before-failing-command.core.json', failure), JSON.stringify(state));
            writeFileSync(new URL('./context.json', failure), JSON.stringify(setup.context, null, 2));
            writeFileSync(new URL('./failure.json', failure), JSON.stringify({ seed: setup.seed,
                nearCount: setup.nearCount, gear: setup.mode, defenderGear: setup.defenderMode,
                error: error.stack, elapsedTicks: advanced, time: state.time,
                command: { type: 'AdvanceTicks', ticks: 5 }, sourceStart, sourceEnd: hashes() }, null, 2));
            throw error;
        }
        advanced += 5;
    }
    const mission = latest(state), encounter = state.world.encounters?.records[mission.task.encounterRules.encounterId];
    const exchanges = encounter?.exchanges ?? [];
    const actions = exchanges.flatMap(value => value.actions);
    const attackerDeaths = state.events.filter(event => event.type === 'PersonaDied' &&
        event.details?.missionId === mission.id);
    const defenderDeaths = state.world.targetClans[setup.rivalId].events.filter(event => event.type === 'PersonaDied' &&
        event.details?.missionId === mission.id);
    const row = { seed: setup.seed, nearCount: setup.nearCount, gearMode: setup.mode, defenderGearMode: setup.defenderMode,
        actualNearbyIds: setup.nearIds, actualCommittedDefenderIds: encounter?.defenderIds ?? [],
        actualCommittedDefenders: encounter?.defenderIds.length ?? 0,
        actualAttackerIds: encounter?.attackerIds ?? [], actualAttackerCount: encounter?.attackerIds.length ?? 0,
        status: mission.status, encounterOutcome: encounter?.outcome ?? null,
        attackerDeaths: attackerDeaths.map(event => ({ id: event.personaId, cause: event.details.cause, time: event.time })),
        defenderDeaths: defenderDeaths.map(event => ({ id: event.personaId, cause: event.details.cause, time: event.time })),
        actions: actions.length, attackerActions: actions.filter(action => action.actorClanId === state.clan.id).length,
        defenderActions: actions.filter(action => action.actorClanId === setup.rivalId).length,
        exchanges: exchanges.length, elapsedTicks: advanced, result: mission.task.result,
        returnedAt: mission.returnedAt, endedAt: mission.endedAt,
        actualReturnedSurvivors: mission.status === 'Returned' ? mission.task.result.survivorIds : [],
        equipment: encounter?.equipment ?? {},
        captureEventId: mission.task.encounterRules.manifest?.captureEventId ?? null,
        deliveredAt: mission.task.encounterRules.manifest?.deliveredAt ?? null,
        sourceEvents: encounter?.sourceEvents ?? [],
    };
    const sample = row.status === 'Returned' && row.attackerDeaths.length === 1 && row.actualReturnedSurvivors.length === 3;
    if (keep || sample) {
        const tag = 'seed-' + setup.seed + '-near-' + setup.nearCount + '-' + setup.mode +
            (setup.defenderMode !== setup.mode ? '-vs-' + setup.defenderMode : '');
        const location = new URL('./' + tag + '/', output);
        mkdirSync(location, { recursive: true });
        writeFileSync(new URL('./before-dispatch.core.json', location), before);
        writeFileSync(new URL('./context.json', location), JSON.stringify(setup.context, null, 2));
        writeFileSync(new URL('./after.core.json', location), core.serializeState(state));
        writeFileSync(new URL('./summary.json', location), JSON.stringify(row, null, 2));
        row.artifactDirectory = fileURLToPath(location);
    }
    return row;
}

const only = process.env.QA_CASE?.split(',');
if (only) {
    const row = run(fixture(Number(only[0]), Number(only[1]), only[2], only[3] ?? only[2]), true);
    writeFileSync(new URL('./single-case.json', output), JSON.stringify({ sourceStart, sourceEnd: hashes(), row }, null, 2));
    console.log(JSON.stringify(row));
    process.exit(0);
}
const rows = [];
for (const seed of [32, 3]) for (const nearCount of [0, 1, 2, 4]) for (const mode of ['none', 'mixed', 'full']) {
    const row = run(fixture(seed, nearCount, mode), true);
    rows.push(row);
    console.log(JSON.stringify({ matrix: true, seed: row.seed, nearby: nearCount, gear: mode,
        committed: row.actualCommittedDefenders, actions: row.actions, dead: row.attackerDeaths.length,
        status: row.status, home: row.actualReturnedSurvivors.length }));
}
const oneSided = [];
for (const seed of [32, 3]) for (const [attackerGear, defenderGear] of [['full', 'none'], ['none', 'full']]) {
    const row = run(fixture(seed, 2, attackerGear, defenderGear), true);
    oneSided.push(row);
    console.log(JSON.stringify({ oneSided: true, seed, attackerGear, defenderGear,
        committed: row.actualCommittedDefenders, dead: row.attackerDeaths.length,
        defenderDeaths: row.defenderDeaths.length, status: row.status, home: row.actualReturnedSurvivors.length }));
}
const search = [];
let sample = rows.find(row => row.status === 'Returned' && row.attackerDeaths.length === 1 && row.actualReturnedSurvivors.length === 3);
for (let seed = 1; seed <= 40 && !sample; seed++) {
    const row = run(fixture(seed, 2, 'mixed'));
    search.push(row);
    console.log(JSON.stringify({ search: true, seed, committed: row.actualCommittedDefenders,
        dead: row.attackerDeaths.length, status: row.status, home: row.actualReturnedSurvivors.length }));
    if (row.status === 'Returned' && row.attackerDeaths.length === 1 && row.actualReturnedSurvivors.length === 3) sample = row;
}
const sourceEnd = hashes();
const report = { generatedAt: new Date().toISOString(), head, pinned: !!pin, sourceStart, sourceEnd,
    sourceUnchangedDuringRun: JSON.stringify(sourceStart) === JSON.stringify(sourceEnd),
    policy: encounterPolicy, fixture: { terrain: 'explicit flat navigable test world',
        actorSource: 'actual createCampaign + initializeIslandClans identities, actual paid public Recon',
        gearSource: 'explicit funded inventory, then public AssignEquipment; no crafting time/RNG drift',
        domesticIsolation: 'natural mortality, fertility and partnership disabled; normal domestic production retained',
        territoryOverride: { maxResponders: 4, ambientRadius: 0 },
        countMeaning: 'nearCount is placement only; actualCommittedDefenders is the factual encountered count',
        gearModes: { none: 'no personal weapon/shield', mixed: 'alternate selected actors have spear + wooden shield',
            full: 'every selected actor has spear + leather shield' },
        matrix: 'two matched seeds (32 and 3), 24 rows; both sides use same gear profile',
        oneSided: 'seeds 32 and 3: full attackers/none defenders and none attackers/full defenders, 2 nearby responders',
        search: 'at most seeds 1..40, nearCount=2, mixed gear; stops at first 1 death / 3 genuine-home survivors case',
        provisional: true, approvedBalance: false }, rows, oneSided, search, sample: sample ?? null };
writeFileSync(new URL('./report-expanded.json', output), JSON.stringify(report, null, 2));
console.log(JSON.stringify({ finished: true, matrixRows: rows.length, searchRows: search.length,
    sourceUnchanged: report.sourceUnchangedDuringRun, sample: sample?.artifactDirectory ?? null }));
