import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { loadTypeScript as loadParent } from '../legacy-compatibility-308-final/parent/scripts/load-typescript.mjs';
import { loadTypeScript as loadCurrent } from '../../scripts/load-typescript.mjs';

const parent = loadParent(new URL('../legacy-compatibility-308-final/parent/src/simulation/SimulationCore.ts', import.meta.url));
const current = loadCurrent(new URL('../../src/simulation/SimulationCore.ts', import.meta.url));
const sha = value => crypto.createHash('sha256').update(typeof value === 'string' || Buffer.isBuffer(value) ? value : JSON.stringify(value)).digest('hex');
const advance = ticks => ({ type: 'AdvanceTicks', ticks });
const apply = (state, command, context) => parent.applyCommand(state, command, context);
const commonRules = { successBps: { Recon: 10000, Surveillance: 10000, Pillage: 10000 },
    casualtyBps: { Recon: 0, Surveillance: 0, Pillage: 0 } };
const frames = [], failures = [], scenarios = [];

function create(seed = 32, calendar, fertility = 0, pillageRisk = 0) {
    return parent.createCampaign(seed, { initialFood: 5000, initialMaterials: 500,
        cattleBirthChanceBps: 0, cattleMortalityYoungBps: 0, cattleMortalityAdultBps: 0,
        cattleMortalityOlderBps: 0, cattleMortalityOldBps: 0 },
        { mortalityBands: [{ minAge: 0, chanceBps: 0 }], fertilityChanceBps: fertility,
            partnershipChanceBps: fertility }, { enabled: false },
        { ...commonRules, casualtyBps: { ...commonRules.casualtyBps, Pillage: pillageRisk } },
        { enabled: false }, {}, undefined, calendar);
}
function firstDifference(left, right, path = '$') {
    if (Object.is(left, right)) return null;
    if (!left || !right || typeof left !== 'object' || typeof right !== 'object')
        return { path, parent: left, current: right };
    const keys = [...new Set([...Object.keys(left), ...Object.keys(right)])];
    for (const key of keys) {
        const difference = firstDifference(left[key], right[key], path + '.' + key);
        if (difference) return difference;
    }
    return null;
}
function compare(name, stage, oldState, newState) {
    const oldText = parent.serializeState(oldState), newText = current.serializeState(newState);
    const equal = oldText === newText;
    frames.push({ scenario: name, stage, equal, time: oldState.time,
        parentSha256: sha(oldText), currentSha256: sha(newText),
        rootRng: { parent: oldState.rngState, current: newState.rngState },
        targetRng: Object.fromEntries(Object.entries(oldState.world?.targetClans ?? {}).map(([id, clan]) =>
            [id, { parent: clan.rngState, current: newState.world.targetClans[id].rngState }])),
        events: { parent: oldState.events.length, current: newState.events.length },
        eventSha256: { parent: sha(oldState.events), current: sha(newState.events) } });
    if (!equal) failures.push({ scenario: name, stage, ...firstDifference(oldState, newState) });
    return equal;
}
function run(name, input, context, commands, facts = {}) {
    scenarios.push({ name, ...facts });
    const text = parent.serializeState(input);
    let oldState = parent.reconstructState(text), newState = current.reconstructState(text);
    compare(name, 'import', oldState, newState);
    for (const [index, command] of commands.entries()) {
        oldState = parent.applyCommand(oldState, command, context);
        newState = current.applyCommand(newState, command, context);
        compare(name, 'command-' + (index + 1) + ':' + command.type + (command.ticks === undefined ? '' : ':' + command.ticks), oldState, newState);
        oldState = parent.reconstructState(parent.serializeState(oldState));
        newState = current.reconstructState(current.serializeState(newState));
        compare(name, 'reload-' + (index + 1), oldState, newState);
    }
    return oldState;
}
function gear(state, ids) {
    state.smithery.stored.woodenSpear = ids.length;
    state.smithery.stored.leatherShield = ids.length;
    for (const personaId of ids) {
        state = apply(state, { type: 'AssignEquipment', personaId, slot: 'weapon', item: 'woodenSpear' });
        state = apply(state, { type: 'AssignEquipment', personaId, slot: 'shield', item: 'leatherShield' });
    }
    return state;
}
function regional({ risk = 0, calendar, fertility = 0 } = {}) {
    let state = create(32, calendar, fertility, risk);
    const ids = Object.keys(state.personas).sort().slice(0, 4);
    const region = Object.values(state.world.regions).find(value => value.targetClanId && !value.requiresShip);
    state = apply(state, { type: 'CreateExpeditionGroup', name: 'Preserved raiders', memberIds: ids });
    state = apply(state, { type: 'DispatchExpedition', groupId: 'group-1', regionId: region.id, mission: 'Recon' });
    state = apply(state, advance(250));
    return { state, ids, region };
}
const bounds = { minX: 0, maxX: 320, minZ: 0, maxZ: 256 };
const world = { waterLevel: -1,
    terrain: { bounds, spacing: 8, columns: 41, rows: 33, heights: Array(1353).fill(0) },
    navigation: { bounds, spacing: 8, columns: 41, rows: 33, cells: Array(1353).fill(true) },
    settlement: { center: { x: 64, z: 128 }, harbor: null },
    rivalSite: { version: 1, candidateId: 'preserved-rival', center: { x: 160, z: 128 },
        bounds: { minX: 128, maxX: 272, minZ: 88, maxZ: 176 }, foundations: [], buildableArea: 12672 } };
const physicalContext = { world, worldId: 'legacy-compatibility-fixture' };
const site = { kind: 'site', siteId: world.rivalSite.candidateId };
function physical({ risk = 0, calendar, fertility = 0 } = {}) {
    let state = parent.initializeIslandClans(create(32, calendar, fertility, risk), world, physicalContext.worldId);
    const ids = Object.keys(state.personas).sort().slice(0, 4);
    state = apply(state, { type: 'CreateExpeditionGroup', name: 'Preserved island party', memberIds: ids }, physicalContext);
    return { state, ids, context: physicalContext };
}
function knowSite(setup) {
    let { state } = setup;
    state = apply(state, { type: 'DispatchIslandMission', groupId: 'group-1',
        target: { kind: 'area', position: { x: 128, z: 128 } }, mission: 'Recon' }, setup.context);
    state = apply(state, advance(250), setup.context);
    assert.ok(parent.inspectIslandMissions(state).sites[0].knowledge?.settlementName);
    return { ...setup, state };
}
function adopt(setup) {
    const rival = setup.state.world.targetClans['island-rival'];
    const homes = (clan, x) => Object.fromEntries(Object.keys(clan.personas).sort().map((id, index) =>
        [id, { x: x + index % 4 * 4, z: 116 + Math.floor(index / 4) * 8 }]));
    const context = { ...setup.context, presenceSites: [
        { clanId: setup.state.clan.id, center: world.settlement.center,
            bounds: { minX: 32, maxX: 112, minZ: 88, maxZ: 176 }, homes: homes(setup.state, 48) },
        { clanId: rival.clan.id, center: world.rivalSite.center, bounds: world.rivalSite.bounds, homes: homes(rival, 156) },
    ] };
    return { ...setup, context, state: parent.initializeTerritorialAwareness(setup.state, context, { ambientRadius: 0 }) };
}
function latestPhysical(state) { return Object.values(state.world.spatial.missions).at(-1); }

for (const calendar of [undefined, 'individual-v1']) {
    const oldState = create(32, calendar);
    const newState = current.createCampaign(32, { initialFood: 5000, initialMaterials: 500,
        cattleBirthChanceBps: 0, cattleMortalityYoungBps: 0, cattleMortalityAdultBps: 0,
        cattleMortalityOlderBps: 0, cattleMortalityOldBps: 0 },
        { mortalityBands: [{ minAge: 0, chanceBps: 0 }], fertilityChanceBps: 0,
            partnershipChanceBps: 0 }, { enabled: false }, commonRules, { enabled: false }, {}, undefined, calendar);
    compare('fresh-absence-' + (calendar ?? 'legacy'), 'creation', oldState, newState);
    run('ordinary-' + (calendar ?? 'legacy'), oldState, undefined, [advance(137), advance(863), advance(1125)]);
}
{
    const setup = regional({ risk: 10000 });
    let state = gear(setup.state, setup.ids);
    state = apply(state, { type: 'DispatchExpedition', groupId: 'group-1', regionId: setup.region.id,
        mission: 'Pillage', priorities: ['Food', 'Materials', 'People'] });
    state = apply(state, advance(137));
    const completed = run('regional-geared-inflight', state, undefined, [advance(111), advance(252), advance(1250)],
        { gearedMembers: setup.ids.length });
    const report = Object.values(completed.world.missions).at(-1).result;
    assert.ok(report.casualtyIds.length && report.equipment.lost.length);
    run('regional-geared-completed', completed, undefined, [advance(125), advance(875)],
        { actualCasualties: report.casualtyIds, lostEquipment: report.equipment.lost.length });
}
{
    const setup = regional();
    let state = apply(setup.state, { type: 'DispatchExpedition', groupId: 'group-1', regionId: setup.region.id,
        mission: 'Pillage', priorities: ['People'] });
    state = apply(state, advance(500));
    assert.ok(Object.values(state.world.missions).at(-1).result.personaIds.length);
    run('regional-real-identity-transfer-completed', state, undefined, [advance(250), advance(1250)]);
}
{
    let state = create(32, 'individual-v1', 10000);
    state = apply(state, advance(1000));
    const pending = [state, ...Object.values(state.world.targetClans)].reduce((sum, clan) =>
        sum + clan.birthdayCalendar.pendingBirths.length, 0);
    assert.ok(pending > 0);
    run('scheduled-real-pending-births', state, undefined, [advance(125), advance(375), advance(500), advance(1000)],
        { realPendingPlans: pending });
}
{
    const setup = physical();
    let state = apply(setup.state, { type: 'DispatchIslandMission', groupId: 'group-1',
        target: { kind: 'area', position: { x: 128, z: 128 } }, mission: 'Recon' }, setup.context);
    state = apply(state, advance(17), setup.context);
    assert.equal(latestPhysical(state).task.encounterRules, undefined);
    run('physical-pre-adoption-recon-inflight', state, setup.context, [advance(75), advance(158), advance(1000)]);
}
{
    const setup = knowSite(physical({ risk: 10000 }));
    let state = gear(setup.state, setup.ids);
    state = apply(state, { type: 'DispatchIslandMission', groupId: 'group-1', target: site,
        mission: 'Pillage', priorities: ['Food'] }, setup.context);
    state = apply(state, advance(137), setup.context);
    const completed = run('physical-pre-adoption-geared-inflight', state, setup.context,
        [advance(113), advance(250), advance(1000)]);
    const report = latestPhysical(completed).task.result;
    assert.ok(report.casualtyIds.length && report.equipment.lost.length);
    run('physical-pre-adoption-geared-completed', completed, setup.context, [advance(500)],
        { actualCasualties: report.casualtyIds });
}
{
    const setup = adopt(knowSite(physical()));
    let state = apply(setup.state, { type: 'DispatchIslandMission', groupId: 'group-1', target: site,
        mission: 'Pillage', priorities: ['People'] }, setup.context);
    state = apply(state, advance(100), setup.context);
    assert.ok(state.world.territory);
    assert.equal(latestPhysical(state).task.encounterRules, undefined);
    assert.equal(state.livestockPresence, undefined);
    const completed = run('adopted-old-task-no-encounter-rules', state, setup.context,
        [advance(125), advance(275), advance(1000)], { territoryVersion: 1, encounterRulesAbsent: true });
    run('adopted-old-task-completed', completed, setup.context, [advance(500)]);
}
{
    const setup = adopt(knowSite(physical()));
    let state = apply(setup.state, { type: 'StartExpedition', groupId: 'group-1' }, setup.context);
    state = apply(state, { type: 'ExploreArea', groupId: 'group-1', target: { x: 104, z: 192 } }, setup.context);
    state = apply(state, advance(13), setup.context);
    assert.equal(latestPhysical(state).encounterRules, undefined);
    run('adopted-old-free-explore-recall', state, setup.context,
        [advance(17), { type: 'RecallExpedition', groupId: 'group-1' }, advance(200), advance(1000)]);
}
const report = { parentCommit: '455481db00105fdaf67e8e213314eb79da37c7bc',
    parentSource: JSON.parse(fs.readFileSync(new URL('./parent-source-manifest.json', import.meta.url))).sha256,
    currentSource: JSON.parse(fs.readFileSync(new URL('./current-source-manifest.json', import.meta.url))).sha256,
    scriptSha256: sha(fs.readFileSync(new URL(import.meta.url))),
    generatedAt: new Date().toISOString(), scenarios, checkpoints: frames.length,
    passingCheckpoints: frames.filter(frame => frame.equal).length, failures, frames };
const reportText = JSON.stringify(report, null, 2) + '\n';
fs.writeFileSync(new URL('./report.json', import.meta.url), reportText);
fs.writeFileSync(new URL('./report.sha256', import.meta.url), sha(reportText) + '  report.json\n');
console.log(JSON.stringify({ scenarios: scenarios.length, checkpoints: frames.length,
    passingCheckpoints: report.passingCheckpoints, failures, reportSha256: sha(reportText) }, null, 2));
process.exitCode = failures.length ? 1 : 0;
